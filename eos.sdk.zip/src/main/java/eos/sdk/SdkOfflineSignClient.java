package eos.sdk;

import eos.sdk.api.result.PushTransactionResults;
import eos.sdk.api.service.RpcService;
import eos.sdk.chain.transaction.Transaction;
import eos.sdk.client.exception.ApiException;
import eos.sdk.client.http.Generator;
import eos.sdk.client.transaction.NeedSignedTransactionToPush;
import eos.sdk.client.transaction.SignParam;
import eos.sdk.client.transaction.SignedTransactionToPush;
import eos.sdk.client.transaction.TransactionBuilder;
import eos.sdk.utils.BusUtil;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.util.List;


public class SdkOfflineSignClient {
	private RpcService rpcService;
	private TransactionBuilder txBuilder;
	private SdkClient sdkClient;
	public SdkOfflineSignClient(String baseUrl) {
		this(baseUrl, null);
	}

	public SdkOfflineSignClient(String baseUrl, String host) {
		if(baseUrl != null && !baseUrl.isEmpty()){
			rpcService = Generator.createService(RpcService.class, baseUrl, host);
		}
		sdkClient = new SdkClient(baseUrl,host);
		txBuilder = TransactionBuilder.newInstance(sdkClient);
	}

	public TransactionBuilder txBuilder() {
		return txBuilder;
	}

	public SignParam getSignParams() throws IOException {
		return txBuilder.getSignParams();
	}

	public String SignedTransactionToString( SignedTransactionToPush pushTransaction) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		String mapJakcson = mapper.writeValueAsString( new SignedTransactionToPush(pushTransaction.getTxId(), pushTransaction.getCompression(), pushTransaction.getTransaction(), pushTransaction.getSignatures()));
		return mapJakcson;
	}

	public String NeedSignedTransactionToString( NeedSignedTransactionToPush pushTransaction) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		String mapJakcson = mapper.writeValueAsString( new NeedSignedTransactionToPush(pushTransaction.getTxId(), pushTransaction.getCompression(), pushTransaction.getTransaction(), pushTransaction.getByteToSignHash()));
		return mapJakcson;
	}

	public SignedTransactionToPush StringToSignedTransaction( String pushTransaction) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		return mapper.readValue(pushTransaction, SignedTransactionToPush.class);
	}

	public NeedSignedTransactionToPush StringToNeedSignedTransaction( String pushTransaction) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		return mapper.readValue(pushTransaction, NeedSignedTransactionToPush.class);
	}

	public String SignParamToString(SignParam param) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		String mapJakcson = mapper.writeValueAsString(param);
		return mapJakcson;
	}

	public SignParam StringToSignParam(String param) throws IOException {
		ObjectMapper mapper = new ObjectMapper();
		return mapper.readValue(param, SignParam.class);
	}

	public String buildTransferExtBin(String contractAccount, String from, String fromAddress, String toAddress, String quantity, String memo)
			throws ApiException, IOException{
		return txBuilder.buildTransferExtBin(contractAccount, from, fromAddress, toAddress, quantity, memo);
	}
	public PushTransactionResults pushTransaction(String pushTransaction)
			throws ApiException, IOException {
		return sdkClient.pushTransaction(StringToSignedTransaction(pushTransaction));
	}

	public PushTransactionResults pushTransaction(String compression, Transaction pushTransaction, String[] signatures)
			throws ApiException, IOException {
		return sdkClient.pushTransaction(compression, pushTransaction, signatures);
	}

	public String createAccount(SignParam param, String pk, String creator, String newAccount, String address, String owner,
												String active, Long buyRam) throws ApiException, IOException {
		return createAccount(param, pk, creator, newAccount, address, owner, active, buyRam, null, null, null);
	}

	public String createAccount(SignParam param, String pk, String creator, String newAccount, String address, String owner,
								String active, Long buyRam, String stakeNetQuantity, String stakeCpuQuantity, Long transfer)
			throws ApiException, IOException {
		return SignedTransactionToString(txBuilder.buildNewAccountRawTx(param, pk, creator, newAccount, address, owner, active, buyRam,
				stakeNetQuantity, stakeCpuQuantity, transfer));
	}

	public String transfer(SignParam param, String pk, String contractAccount, String from, String to, String quantity,
										   String memo) throws ApiException, IOException {
		return SignedTransactionToString(txBuilder.buildTransferRawTx(param, pk, contractAccount, from, to, quantity, memo));
	}

	public String transferExt(SignParam param, String pk, String contractAccount, String from, String fromAddress, String toAddress, String quantity,
										   String memo) throws ApiException, IOException {
		return SignedTransactionToString(txBuilder.buildTransferExtRawTx(param, pk, contractAccount, from, fromAddress, toAddress, quantity, memo));
	}

	public String transferExt(SignParam param, String pk, String contractAccount, String fromAddress, String toAddress, String quantity,
							  String memo) throws ApiException, IOException {
		return SignedTransactionToString(txBuilder.buildTransferExtRawTx(param, pk, contractAccount, BusUtil.getAccountNameByMainOrSubAddress(fromAddress), fromAddress, toAddress, quantity, memo));
	}

	public String transferExtWithMoreSign(SignParam param, String pk, String contractAccount, String fromAddress, String toAddress, String quantity,
							  String memo) throws ApiException, IOException {
		return SignedTransactionToString(txBuilder.buildTransferExtWithMoreSignRawTx(param, pk, contractAccount, BusUtil.getAccountNameByMainOrSubAddress(fromAddress), fromAddress, toAddress, quantity, memo));
	}

	public String transferExtWithMark(SignParam param, String pk, String contractAccount, String fromAddress, String toAddress, String quantity,
							  String memo, String mark) throws ApiException, IOException {
		return SignedTransactionToString(txBuilder.buildTransferExtWithMarkRawTx(param, pk, contractAccount, BusUtil.getAccountNameByMainOrSubAddress(fromAddress), fromAddress, toAddress, quantity, memo, mark));
	}

	public String transferExtWithFee(SignParam param, String pk, String contractAccount, String fromAddress, String toAddress, String quantity,
							  String memo, String quantityFee) throws ApiException, IOException {
		return SignedTransactionToString(txBuilder.buildTransferExtWithFeeRawTx(param, pk, contractAccount, BusUtil.getAccountNameByMainOrSubAddress(fromAddress), fromAddress, toAddress, quantity, memo, quantityFee));
	}

	public String addHdAddress(SignParam param, String pk, String contractAccount, String account, String address) throws ApiException, IOException {
		return SignedTransactionToString(txBuilder.buildAddHdAddressRawTx(param, pk, contractAccount, account, address));
	}

	public String applyIssue(SignParam param, String pk, String account) throws ApiException, IOException {
		return SignedTransactionToString(txBuilder.buildApplyIssueRawTx(param, pk, account));
	}

	public String needSignApplyIssue(SignParam param, String account) throws ApiException, IOException {
		return NeedSignedTransactionToString(txBuilder.buildNeedSignApplyIssueRawTx(param, account));
	}

	public String unApplyIssue(SignParam param, String pk, String account) throws ApiException, IOException {
		return SignedTransactionToString(txBuilder.buildUnApplyIssueRawTx(param, pk, account));
	}

	public String needSignUnApplyIssue(SignParam param, String account) throws ApiException, IOException {
		return NeedSignedTransactionToString(txBuilder.buildNeedSignUnApplyIssueRawTx(param, account));
	}

	public String addAttachPermission(SignParam param, String pk, String account, String permission, String parent, String publicKey, String codeAccount,  String codePermission) throws ApiException, IOException {
		return SignedTransactionToString(txBuilder.buildAddAttachPermissionRawTx(param, pk, account, permission, parent, publicKey, codeAccount, codePermission));
	}

	public String removeAttachPermission(SignParam param, String pk, String account, String permission, String parent, String publicKey) throws ApiException, IOException {
		return SignedTransactionToString(txBuilder.buildRemoveAttachPermissionRawTx(param, pk, account, permission, parent, publicKey));
	}

	public String addNewPermission(SignParam param, String pk, String account, String permission, String parent, String publicKey) throws ApiException, IOException {
		return SignedTransactionToString(txBuilder.buildAddNewPermissionRawTx(param, pk, account, permission, parent, publicKey));
	}

	public String voteProducer(SignParam param, String pk, String voter, String proxy, List<String> producers)
			throws ApiException, IOException {
		return SignedTransactionToString(txBuilder.buildVoteProducerRawTx(param, pk, voter, proxy, producers));
	}

	public String buyram(SignParam param, String pk, String creator, String receiver, String quantity)
			throws ApiException, IOException {
		return SignedTransactionToString(txBuilder.buildBuyramRawTx(param, pk, creator, receiver, quantity));
	}

	public String delegatebw(SignParam param, String pk, String from, String receiver, String stakeNetQuantity, String stakeCpuQuantity, Long transfer)
			throws ApiException, IOException {
		return SignedTransactionToString(txBuilder.buildDelegatebwRawTx(param, pk, from, receiver, stakeNetQuantity,stakeCpuQuantity,transfer));
	}

	public String updateUserAuthKey(SignParam param, String pk, String actor, String kind, String newPublicKey)
			throws ApiException, IOException {
		return SignedTransactionToString(txBuilder.buildUpdateUserAuthKeyRawTx(param, pk, actor, kind, newPublicKey));
	}
}
