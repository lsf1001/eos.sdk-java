package eos.sdk.api.result;

import eos.sdk.chain.trace.ActionTrace;
import eos.sdk.chain.trace.TransactionTrace;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;


@JsonIgnoreProperties(ignoreUnknown = true)
public class PushTransactionResults {
	@JsonProperty("transaction_id")
	@Getter
	@Setter
	private String transactionId;

	@JsonProperty("processed")
	@Getter
	@Setter
	private TransactionTrace processed;

	public ArrayList<String> getConsole(){
		List<ActionTrace> actionTraceList = this.getProcessed().getActionTraces();
		ArrayList<String> al =new ArrayList<>();
		getActionTraceList(al,actionTraceList);
		return al;
	}

	private void getActionTraces(ArrayList<String> al,ActionTrace actionTrace) {
		List<ActionTrace> actionTraceList = actionTrace.getInlineTraces();
		getActionTraceList(al,actionTraceList);
	}
	private void getActionTraceList(ArrayList<String> al,List<ActionTrace> actionTraceList) {
		ActionTrace subActionTrace;
		String consoleStr;
		for (int i = 0, j = actionTraceList.size(); i < j; i++) {
			subActionTrace = actionTraceList.get(i);
			consoleStr = subActionTrace.getConsole();
			if (consoleStr != "") {
				al.add(consoleStr);
			}
			getActionTraces(al, subActionTrace);
		}
	}
}
