package eos.sdk.api.result;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;


@JsonIgnoreProperties(ignoreUnknown = true)
public class GetInfoResults {
	@JsonProperty("server_version")
	@Getter
	@Setter
	private String serverVersion;

	@JsonProperty("chain_id")
	@Getter
	@Setter
	private String chainId;

	@JsonProperty("head_block_num")
	@Getter
	@Setter
	private Long headBlockNum;

	@JsonProperty("last_irreversible_block_num")
	@Getter
	@Setter
	private Long lastIrreversibleBlockNum;

	@JsonProperty("last_irreversible_block_id")
	@Getter
	@Setter
	private String lastIrreversibleBlockId;

	@JsonProperty("head_block_id")
	@Getter
	@Setter
	private String headBlockId;

	@JsonFormat(pattern="yyyy-MM-dd'T'HH:mm:ss.SSS")
	@JsonProperty("head_block_time")
	@Getter
	@Setter
	private Date headBlockTime;

	@JsonProperty("head_block_producer")
	@Getter
	@Setter
	private String headBlockProducer;

	@JsonProperty("virtual_block_cpu_limit")
	@Getter
	@Setter
	private String virtualBlockCpuLimit;

	@JsonProperty("virtual_block_net_limit")
	@Getter
	@Setter
	private String virtualBlockNetLimit;

	@JsonProperty("block_cpu_limit")
	@Getter
	@Setter
	private String blockCpuLimit;

	@JsonProperty("block_net_limit")
	@Getter
	@Setter
	private String blockNetLimit;
}
