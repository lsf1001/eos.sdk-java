package eos.sdk.api.result.error;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;


@JsonIgnoreProperties(ignoreUnknown = true)
public class ApiError {
	@JsonProperty("message")
	@Getter
	@Setter
	private String message;

	@JsonProperty("code")
	@Getter
	@Setter
	private String code;

	@JsonProperty("error")
	@Getter
	@Setter
	private Error error;
}
