package eos.sdk.api.result;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AbiJsonToBinResults {
	@JsonProperty("binargs")
    @Getter
    @Setter
    private String binargs;

    @JsonProperty("required_scope")
    @Getter
    @Setter
    private List<String> requiredScope;

    @JsonProperty("required_auth")
    @Getter
    @Setter
    private List<String> requiredAuth;
}
