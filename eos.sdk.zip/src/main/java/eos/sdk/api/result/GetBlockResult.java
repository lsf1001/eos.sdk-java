package eos.sdk.api.result;

import eos.sdk.api.result.get_block.BlockPackedTransaction;
import eos.sdk.chain.block.SignedBlock;
import eos.sdk.chain.block.TransactionReceipt;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;


@JsonIgnoreProperties(ignoreUnknown = true)
public class GetBlockResult extends SignedBlock<TransactionReceipt<BlockPackedTransaction>> {
	@JsonProperty("id")
	@Getter
	@Setter
	private String id;

	@JsonProperty("block_num")
	@Getter
	@Setter
	private Long blockNum;

	@JsonProperty("ref_block_prefix")
	@Getter
	@Setter
	private Long refBlockPrefix;
}
