package eos.sdk.api.result;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;


@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class CurrencyStatsResult {
	@JsonProperty("supply")
	@Getter
	@Setter
	private String supply;

	@JsonProperty("max_supply")
	@Getter
	@Setter
	private String maxSupply;

	@JsonProperty("issuer")
	@Getter
	@Setter
	private String issuer;
}
