package eos.sdk.api.result;

import eos.sdk.chain.AccountResourceLimit;
import eos.sdk.chain.authority.Permission;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.List;


@JsonIgnoreProperties(ignoreUnknown = true)
public class GetAccountResults {

	@JsonProperty("account_name")
	@Getter
	@Setter
	private String accountName;
	
	@JsonProperty("head_block_num")
	@Getter
	@Setter
	private Long headBlockNum;
	
	@JsonFormat(pattern="yyyy-MM-dd'T'HH:mm:ss.SSS")
	@JsonProperty("head_block_time")
	@Getter
	@Setter
	private Date headBlockTime;
	
	@JsonProperty("privileged")
	@Getter
	@Setter
	private Boolean privileged;

	@JsonFormat(pattern="yyyy-MM-dd'T'HH:mm:ss.SSS")
	@JsonProperty("last_code_update")
	@Getter
	@Setter
	private Date lastCodeUpdate;

	@JsonFormat(pattern="yyyy-MM-dd'T'HH:mm:ss.SSS")
	@JsonProperty("created")
	@Getter
	@Setter
	private Date created;

	@JsonProperty("ram_quota")
	@Getter
	@Setter
	private Long ramQuota;

	@JsonProperty("net_weight")
	@Getter
	@Setter
	private Long netWeight;

	@JsonProperty("cpu_weight")
	@Getter
	@Setter
	private Long cpuWeight;

	@JsonProperty("net_limit")
	@Getter
	@Setter
	private AccountResourceLimit netLimit;

	@JsonProperty("cpu_limit")
	@Getter
	@Setter
	private AccountResourceLimit cpuLimit;

	@JsonProperty("ram_usage")
	@Getter
	@Setter
	private Long ramUsage;

	@JsonProperty("permissions")
	@Getter
	@Setter
	private List<Permission> permissions;

	@JsonProperty("total_resources")
	@Getter
	@Setter
	private Object totalResources;
	
	@JsonProperty("self_delegated_bandwidth")
	@Getter
	@Setter
	private Object selfDelegatedBandwidth;
	
	@JsonProperty("refund_request")
	@Getter
	@Setter
	private Object refundRequest;
	
	@JsonProperty("voter_info")
	@Getter
	@Setter
	private Object voterInfo;
}
