package eos.sdk.api.result.get_block;

import eos.sdk.chain.transaction.PackedTransaction;
import eos.sdk.chain.transaction.Transaction;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class BlockPackedTransaction extends PackedTransaction {

	@JsonProperty("id")
	@Getter
	@Setter
	private String id;

	@JsonProperty("context_free_data")
	@Getter
	@Setter
	private List<Object> contextFreeData;

	@JsonProperty("transaction")
	@Getter
	@Setter
	private Transaction transaction;

	public BlockPackedTransaction() {

	}

	public BlockPackedTransaction(String txId) {
		super(txId);
	}
}
