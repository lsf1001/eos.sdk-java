package eos.sdk.api.result.error;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;


@JsonIgnoreProperties(ignoreUnknown = true)
public class ErrorDetails {
	@JsonProperty("message")
	@Getter
	@Setter
	private String message;

	@JsonProperty("file")
	@Getter
	@Setter
	private String file;

	@JsonProperty("line_number")
	@Getter
	@Setter
	private Integer lineNumber;

	@JsonProperty("method")
	@Getter
	@Setter
	private String method;
}
