package eos.sdk.api.result;

import eos.sdk.api.result.get_transaction.TrxAndReceipt;
import eos.sdk.chain.trace.ActionTrace;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class GetTransactionResult {
	@JsonProperty("id")
	@Getter
	@Setter
	private String id;

	@JsonProperty("trx")
	@Getter
	@Setter
	private TrxAndReceipt trx;

	@JsonProperty("block_time")
	@Getter
	@Setter
	private Date blockTime;

	@JsonProperty("block_num")
	@Getter
	@Setter
	private Long blockNum;

	@JsonProperty("last_irreversible_block")
	@Getter
	@Setter
	private Long lastIrreversibleBlock;

	@JsonProperty("traces")
	@Getter
	@Setter
	private List<ActionTrace> traces;
}
