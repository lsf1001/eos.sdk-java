package eos.sdk.api.result.error;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;


@JsonIgnoreProperties(ignoreUnknown = true)
public class Error {
	@JsonProperty("code")
	@Getter
	@Setter
	private String code;

	@JsonProperty("name")
	@Getter
	@Setter
	private String name;

	@JsonProperty("what")
	@Getter
	@Setter
	private String what;

	@JsonProperty("details")
	@Getter
	@Setter
	private ErrorDetails[] details;
}
