package eos.sdk.api.result.get_transaction;

import eos.sdk.chain.transaction.PackedTransaction;
import eos.sdk.chain.transaction.SignedTransaction;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
public class TrxAndReceipt {
	@JsonProperty("receipt")
	@Getter
	@Setter
	private TransactionReceiptWithTrxList<PackedTransaction> receipt;
	
	@JsonProperty("trx")
	@Getter
	@Setter
	private SignedTransaction trx;
}
