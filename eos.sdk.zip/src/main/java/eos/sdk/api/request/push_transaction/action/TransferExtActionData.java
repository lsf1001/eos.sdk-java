package eos.sdk.api.request.push_transaction.action;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import eos.sdk.client.pack.Pack;
import eos.sdk.client.pack.PackType;
import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
public class TransferExtActionData extends BaseActionData {
	@Pack(PackType.string)
	@JsonProperty("from_address")
	@Getter
	@Setter
	private String fromAddress;

	@Pack(PackType.string)
	@JsonProperty("to_address")
	@Getter
	@Setter
	private String toAddress;

	@Pack(PackType.asset)
	@JsonProperty("quantity")
	@Getter
	@Setter
	private String quantity;

	@Pack(PackType.string)
	@JsonProperty("memo")
	@Getter
	@Setter
	private String memo;
}
