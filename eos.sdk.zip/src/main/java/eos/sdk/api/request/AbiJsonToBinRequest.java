package eos.sdk.api.request;

import lombok.Getter;
import lombok.Setter;

import java.util.Map;

public class AbiJsonToBinRequest {
    @Getter
    @Setter
    private String code;

    @Getter
    @Setter
    private String action;

    @Getter
    @Setter
    private Map<String, String> args;

    public AbiJsonToBinRequest(String code, String action, Map<String, String> args) {
        this.code = code;
        this.action = action;
        this.args = args;
    }
}
