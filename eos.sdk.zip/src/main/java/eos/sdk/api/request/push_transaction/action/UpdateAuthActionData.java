package eos.sdk.api.request.push_transaction.action;

import eos.sdk.chain.authority.Authority;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import eos.sdk.client.pack.Pack;
import eos.sdk.client.pack.PackType;
import lombok.Getter;
import lombok.Setter;


@JsonIgnoreProperties(ignoreUnknown = true)
public class UpdateAuthActionData extends BaseActionData {
	@Pack(PackType.name)
	@JsonProperty("account")
	@Getter
	@Setter
	private String account;

	@Pack(PackType.name)
	@JsonProperty("permission")
	@Getter
	@Setter
	private String permission;

	@Pack(PackType.name)
	@JsonProperty("parent")
	@Getter
	@Setter
	private String parent;

	@Pack
	@JsonProperty("auth")
	@Getter
	@Setter
	private Authority auth;
}
