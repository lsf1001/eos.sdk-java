package eos.sdk.api.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
public class GetCurrencyBalanceRequest {
	@Getter
	@Setter
	String code;

	@Getter
	@Setter
	String account;

	@Getter
	@Setter
	String symbol;
}
