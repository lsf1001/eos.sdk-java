package eos.sdk.api.request.push_transaction.action;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import eos.sdk.client.pack.Pack;
import eos.sdk.client.pack.PackType;
import lombok.Getter;
import lombok.Setter;


@JsonIgnoreProperties(ignoreUnknown = true)
public class BuyramActionData extends BaseActionData {

	@Pack(PackType.name)
	@JsonProperty("payer")
	@Getter
	@Setter
	private String payer;

	@Pack(PackType.name)
	@JsonProperty("receiver")
	@Getter
	@Setter
	private String receiver;

	@Pack(PackType.asset)
	@JsonProperty("quant")
	@Getter
	@Setter
	private String quant;
}
