package eos.sdk.api.request.push_transaction.action;

import eos.sdk.client.pack.Pack;
import eos.sdk.client.pack.PackType;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
public class UnDelegatebwActionData extends BaseActionData {
	@Pack(PackType.name)
	@JsonProperty("from")
	@Getter
	@Setter
	private String from;

	@Pack(PackType.name)
	@JsonProperty("receiver")
	@Getter
	@Setter
	private String receiver;

	@Pack(PackType.asset)
	@JsonProperty("stake_net_quantity")
	@Getter
	@Setter
	private String stakeNetQuantity;

	@Pack(PackType.asset)
	@JsonProperty("stake_cpu_quantity")
	@Getter
	@Setter
	private String stakeCpuQuantity;
}
