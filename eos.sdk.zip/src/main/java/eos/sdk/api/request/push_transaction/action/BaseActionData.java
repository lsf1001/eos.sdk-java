package eos.sdk.api.request.push_transaction.action;

import eos.sdk.utils.Hex;
import eos.sdk.client.pack.PackUtils;
import eos.sdk.utils.ByteBuffer;

public class BaseActionData {

	public String toString() {
		ByteBuffer bb = new ByteBuffer();
		PackUtils.packObj(this, bb);
		return Hex.bytesToHexString(bb.getBuffer());
	}
}
