package eos.sdk.api.request.push_transaction.action;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import eos.sdk.client.pack.Pack;
import eos.sdk.client.pack.PackType;
import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
public class AddMarkActionData extends BaseActionData {
	@Pack(PackType.name)
	@JsonProperty("owner")
	@Getter
	@Setter
	private String owner;

	@Pack(PackType.string)
	@JsonProperty("mark")
	@Getter
	@Setter
	private String mark;
}
