package eos.sdk.api.request.push_transaction.action;

import eos.sdk.client.pack.Pack;
import eos.sdk.client.pack.PackType;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class VoteProducerActionData extends BaseActionData {
	@Pack(PackType.name)
	@JsonProperty("voter")
	@Getter
	@Setter
	private String voter;

	@Pack(PackType.name)
	@JsonProperty("proxy")
	@Getter
	@Setter
	private String proxy;

	@Pack(PackType.name)
	@JsonProperty("producers")
	@Getter
	@Setter
	private List<String> producers;
}
