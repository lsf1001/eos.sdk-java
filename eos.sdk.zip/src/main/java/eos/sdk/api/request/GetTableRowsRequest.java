package eos.sdk.api.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
public class GetTableRowsRequest {
	@JsonProperty("code")
	@Getter
	@Setter
	private String code = "eos";

	@JsonProperty("scope")
	@Getter
	@Setter
	private String scope;

	@JsonProperty("table")
	@Getter
	@Setter
	private String table;

	@JsonProperty("json")
	@Getter
	@Setter
	private Boolean json = true;

	@JsonProperty("limit")
	@Getter
	@Setter
	private int limit = 10;
	
	@JsonProperty("lower_bound")
	@Getter
	@Setter
	private String lowerBound;

	@JsonProperty("upper_bound")
	@Getter
	@Setter
	private String upperBound;

	@JsonProperty("table_key")
	@Getter
	@Setter
	private String tableKey;

	@JsonProperty("key_type")
	@Getter
	@Setter
	private String keyType;

	@JsonProperty("index_position")
	@Getter
	@Setter
	private int indexPosition;

	@JsonProperty("reverse")
	@Getter
	@Setter
	private Boolean reverse = false;

	@JsonProperty("show_payer")
	@Getter
	@Setter
	private Boolean showPayer = false;
}
