package eos.sdk.api.request.push_transaction.action;

import eos.sdk.client.pack.Pack;
import eos.sdk.client.pack.PackType;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
public class Collect extends BaseActionData{
	@Pack(PackType.name)
	@JsonProperty("collected_name")
	@Getter
	@Setter
	private String collectedName;
}
