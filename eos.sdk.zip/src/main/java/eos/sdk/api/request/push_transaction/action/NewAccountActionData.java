package eos.sdk.api.request.push_transaction.action;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import eos.sdk.client.pack.Pack;
import eos.sdk.client.pack.PackType;
import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
public class NewAccountActionData extends BaseActionData {

	@Pack(PackType.name)
	@JsonProperty("creator")
	@Getter
	@Setter
	private String creator;

	@Pack(PackType.name)
	@JsonProperty("name")
	@Getter
	@Setter
	private String name;

	@Pack(PackType.string)
	@JsonProperty("address")
	@Getter
	@Setter
	private String address;

	@Pack(PackType.key)
	@JsonProperty("owner")
	@Getter
	@Setter
	private String owner;

	@Pack(PackType.key)
	@JsonProperty("active")
	@Getter
	@Setter
	private String active;
}
