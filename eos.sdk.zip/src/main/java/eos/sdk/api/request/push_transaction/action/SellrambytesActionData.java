package eos.sdk.api.request.push_transaction.action;

import eos.sdk.client.pack.Pack;
import eos.sdk.client.pack.PackType;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SellrambytesActionData {
	@Pack(PackType.name)
	@JsonProperty("account")
	@Getter
	@Setter
	private String account;
	
	@Pack(PackType.uint64)
	@JsonProperty("bytes")
	@Getter
	@Setter
	private Long bytes;
}
