package eos.sdk.api.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
public class GetAccountsRequest {
	@JsonProperty("public_key")
	@Getter
	@Setter
	private String publicKey;
}
