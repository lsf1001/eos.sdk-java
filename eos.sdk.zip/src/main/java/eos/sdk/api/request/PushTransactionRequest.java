package eos.sdk.api.request;

import eos.sdk.chain.transaction.Transaction;
import lombok.Getter;
import lombok.Setter;


public class PushTransactionRequest {
	@Getter
	@Setter
	private String compression;

	@Getter
	@Setter
	private Transaction transaction;

	@Getter
	@Setter
	private String[] signatures;

	public PushTransactionRequest(String compression, Transaction transaction, String[] signatures) {
		this.compression = compression;
		this.transaction = transaction;
		this.signatures = signatures;
	}
}
