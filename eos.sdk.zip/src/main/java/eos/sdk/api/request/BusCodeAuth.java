package eos.sdk.api.request;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;


@Data
public class BusCodeAuth {
    @Getter
    @Setter
    boolean auth;

    @Getter
    @Setter
    String contractAccount;

    @Getter
    @Setter
    String actor;
}
