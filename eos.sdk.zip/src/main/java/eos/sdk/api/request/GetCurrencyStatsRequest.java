package eos.sdk.api.request;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;


@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class GetCurrencyStatsRequest {
	@Getter
	@Setter
	String code;

	@Getter
	@Setter
	String symbol;
}
