package eos.sdk.utils;

import eos.sdk.api.request.push_transaction.action.TransferExtActionData;
import eos.sdk.chain.action.Action;
import eos.sdk.chain.transaction.Transaction;
import eos.sdk.client.transaction.SignedTransactionToPush;
import eos.sdk.client.transaction.TransactionToSign;
import eos.sdk.crypto.EccTool;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.List;

public class SetMoreSignUtil {
    public static void setMoreSign(String pk, String chainId, SignedTransactionToPush signedTransaction) throws Exception {
        ObjectMapper mapper = new ObjectMapper();
        Transaction oldTx = signedTransaction.getTransaction();
        String oldJson = mapper.writeValueAsString(oldTx);
        Transaction tx = mapper.readValue(oldJson, Transaction.class);

        List<Action> actions = tx.getActions();
        Action action = actions.get(0);
        TransferExtActionData dataMap = UnPacker.transferExt(action.getData().toString(), "sys.token");
        action.setData(dataMap);
        actions.clear();
        actions.add(action);
        tx.setActions(actions);
        String sign = EccTool.signTransaction(pk, new TransactionToSign(chainId, tx));
        String[] signatures = new String[2];
        signatures[0] = signedTransaction.getSignatures()[0];
        signatures[1] = sign;
        signedTransaction.setSignatures(signatures);
    }
}
