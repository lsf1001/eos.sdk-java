package eos.sdk.utils;

import eos.sdk.api.request.push_transaction.action.TransferExtActionData;
import eos.sdk.client.pack.AssetQuantity;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.LinkedHashMap;
import java.util.Map;

public class UnPacker {
    static private int nextPos = 0;
    public static TransferExtActionData transferExt(String data, String contractAccount) {
        TransferExtActionData dataMap = new TransferExtActionData();
        dataMap.setFromAddress(unpack(data, 0));
        dataMap.setToAddress(unpack(data, nextPos));
        dataMap.setQuantity(AssetQuantity.parse(unpackAsset(data, nextPos), contractAccount));
        dataMap.setMemo(unpack(data, nextPos + 32));
        return dataMap;
    }

    public static Map<String, Object> transfer(String data) {
        Map<String, Object> dataMap = new LinkedHashMap<>();
        dataMap.put("from", unpackName(data, 0));
        dataMap.put("to", unpackName(data, 16));
        dataMap.put("quantity", unpackAsset(data, 32));
        dataMap.put("memo", unpack(data, 64));
        return dataMap;
    }

    public static Map<String, Object> addHdAddress(String data) {
        Map<String, Object> dataMap = new LinkedHashMap<>();
        dataMap.put("account", unpackName(data, 0));
        dataMap.put("address", unpack(data, 16));
        return dataMap;
    }

    public static String unpackName(String data, int pos) {
        String name = data.substring(pos, pos + 16);
        return UnPackUtil.getLongNameToString(UnPackUtil.getLongFromLEBytes(UnPackUtil.convertHexStrToBytes(name)));
    }

    public static String unpackAsset(String data, int pos) {
        String asset = data.substring(pos, pos + 32);
        String hexAmount = asset.substring(0, 16);
        String hexPrecision = asset.substring(16, 18);
        String hexSymbol = asset.substring(18);
        String amount = UnPackUtil.getLongFromLEBytes(UnPackUtil.convertHexStrToBytes(hexAmount)) + "";
        int precision = Integer.parseInt(hexPrecision, 16);
        String symbol = UnPackUtil.convertHexToAscii(hexSymbol);
        BigDecimal b = new BigDecimal(amount);
        return  b.divide(BigDecimal.TEN.pow(precision),precision, RoundingMode.FLOOR).toPlainString() + " " + symbol;
    }

    public static String newUnpackAsset(String data, int pos) {
        String asset = data.substring(pos, pos + 32);
        String hexAmount = asset.substring(0, 16);
        String hexPrecision = asset.substring(16, 18);
        String hexSymbol = asset.substring(18);
        String amount = UnPackUtil.getLongFromLEBytes(UnPackUtil.convertHexStrToBytes(hexAmount)) + "";
        int precision = Integer.parseInt(hexPrecision, 16);
        String symbol = UnPackUtil.convertHexToAscii(hexSymbol);
        int index = amount.length() - precision;
        if (index >= 0) {
            return (index == 0 ? "0" : amount.substring(0, index)) + "." + amount.substring(index) + " " + symbol;
        } else {
            int num0 = 0 - index;
            String z0 = "";
            for (int i = 0; i < num0; i++) {
                z0 = z0 + "0";
            }
            String amount0 = "0." + z0 + amount + " " + symbol;
            return amount0;
        }

    }


    public static String unpack(String data, int pos) {
        int start = pos + 2;
        if (start > data.length()) {
            return null;
        }
        String lengthstr = data.substring(pos, start);
        int length = Integer.parseInt(lengthstr, 16) * 2;
        if (length > data.length()) {
            return null;
        }
        nextPos = start + length;
        return UnPackUtil.convertHexToAscii(data.substring(start, start + length));
    }

}
