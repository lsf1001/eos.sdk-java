package eos.sdk.utils.buskey;

//import io.github.novacrypto.bip39.MnemonicGenerator;
//import io.github.novacrypto.bip39.Words;
//import io.github.novacrypto.bip39.wordlists.English;
import org.bouncycastle.jce.provider.BouncyCastleProvider;

        import java.security.Security;


public class BusKeyUtils {
    public static final String K_mnemonic = "mnemonic";
    public static final String K_privateKey = "privateKey";
    public static final String K_publicKey = "publicKey";

    static{
        Security.addProvider(new BouncyCastleProvider());
    }
//
//    public static String randomKey() {
//        return generateKey().get(K_privateKey).toString();
//    }
//
//    public static String randomPubKey() {
//        return generateKey().get(K_publicKey).toString();
//    }

    public static String getPublicKey(String privateKey) {
        try {
            BusPrivateKey busPrivateKey = new BusPrivateKey(privateKey);
            BusPublicKey busPublicKeyFromPrivateKey = busPrivateKey.getPublicKey();
            return busPublicKeyFromPrivateKey.toBusString();
        } catch (BusKeyException ex) {
            return null;
        }
    }

//    public static Map generateKey() {
//        Map<String, String> resultMap = null;
//        try {
//            StringBuilder sb = new StringBuilder();
//            byte[] entropy = new byte[Words.TWELVE.byteLength()];
//            new SecureRandom().nextBytes(entropy);
//            new MnemonicGenerator(English.INSTANCE)
//                    .createMnemonic(entropy, sb::append);
//            String mnemonic = sb.toString();
//            String privateKey = EccTool.privateKeyFromSeed(mnemonic);
//            String publicKey = getPublicKey(privateKey);
//            resultMap = new LinkedHashMap<>();
//            resultMap.put(K_mnemonic, mnemonic);
//            resultMap.put(K_privateKey, privateKey);
//            resultMap.put(K_publicKey, publicKey);
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return resultMap;
//    }
}
