package eos.sdk.utils.buskey;


public class BusKeyException extends Exception {
    public BusKeyException(String s) {
        super(s);
    }

    public BusKeyException(String s, Throwable throwable) {
        super(s, throwable);
    }
}
