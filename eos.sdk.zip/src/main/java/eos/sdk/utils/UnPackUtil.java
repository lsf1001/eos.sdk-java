package eos.sdk.utils;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class UnPackUtil {
    private static final char[] charMap = ".12345abcdefghijklmnopqrstuvwxyz".toCharArray();

    public static byte[] convertHexStrToBytes(String hex) {
        byte[] result = new byte[hex.length() * 2];
        for (int i = 0; i < hex.length(); i += 2) {
            byte b = (byte) ((hex.charAt(i) % 32 + 9) % 25 * 16 + (hex.charAt(i + 1) % 32 + 9) % 25);
            result[i / 2] = b;
        }
        return result;
    }

    public static String convertHexToAscii(String hex) {
        StringBuilder output = new StringBuilder();
        for (int i = 0; i < hex.length(); i += 2) {
            String str = hex.substring(i, i + 2);
            if (!str.equals("00")) {
                output.append((char) Integer.parseInt(str, 16));
            }
        }
        return output.toString();
        //.replaceFirst("([^a-zA-Z])+", "");
    }

    public static long getLongFromLEBytes(byte[] bytes) {
        ByteBuffer buffer = ByteBuffer.wrap(bytes);
        buffer.order(ByteOrder.LITTLE_ENDIAN);
        return buffer.getLong();
    }

    public static String getLongNameToString(long name) {
        char[] array = new char[13];
        for (int i = 0; i <= 12; ++i) {
            char c = charMap[(int) (name & (i == 0 ? 0x0f : 0x1f))];
            array[12 - i] = c;
            name >>= (i == 0 ? 4 : 5);
        }
        String strRaw = new String(array);
        return strRaw.replaceAll("[.]+$", "");
    }
}
