package eos.sdk.utils;

import eos.sdk.api.result.error.Error;
import eos.sdk.client.exception.ApiException;
import eos.sdk.dto.ErrorInfoDTO;

import java.security.SecureRandom;
import java.util.regex.Pattern;


public class BusUtil {

    public static String randomName() {
        String randomStr = "";
        String[] baseStr = {"a","b","c","d","e","f","g","h","i","g","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","1","2","3","4","5"};
        for(int i = 0; i < 12; i++){
            int random = new SecureRandom().nextInt(30);
            randomStr += baseStr[random];
        }
        return randomStr;
    }

//    public static String randomAddress() {
//        String randomPubKey = BusKeyUtils.randomPubKey();
//        return "BR" + randomPubKey.substring(4);
//    }

//    public static String randomMainAddress(String accountName) {
//        return randomCustomAddress("BRM", accountName);
//    }
//
//    public static String randomSubAddress(String accountName) {
//        return randomCustomAddress("BRS", accountName);
//    }

    public static String getAccountNameByMainOrSubAddress(String address) {
    	if(address.substring(0, 3).equals("BRM")||address.substring(0, 3).equals("BRS")) {
    		return address.substring(3,15).toLowerCase();
    	}
    	return address.substring(2,14).toLowerCase();
    }

    // B_(M/S)_accountName_suffix
//    private static String randomCustomAddress(String prefix, String accountName) throws ApiException{
//        String randomPubKey = BusKeyUtils.randomPubKey();
//        String suffix = randomPubKey.substring(4);
//        if(accountName.length() != 12 || !checkName(accountName)){
//            ApiError apiError = new ApiError();
//            apiError.setMessage("accountName parse error");
//            throw new ApiException(apiError);
//        }
//        suffix = accountName.toUpperCase() + suffix.substring(13);
//        return prefix + suffix;
//    }

    public static boolean checkName(String name){
        String pattern = "^[a-z\\.12345]{12}$";
        return Pattern.matches(pattern, name);
    }

    public static boolean checkPublicKey(String publicKey){
        return (publicKey.substring(0, 3).equals("BUS") && publicKey.length() == 53);
    }

    public static boolean checkPrivateKey(String privateKey){
        return (privateKey.substring(0, 1).equals("5") && privateKey.length() == 51);
    }

    public static boolean checkAddress(String address){
    	if(address.substring(0, 2).equals("BR")) {
    		return (address.substring(0, 2).equals("BR") && address.length() == 51);
    	}
        return (address.substring(0, 1).equals("B") && address.length() == 51);
    }

    public static ErrorInfoDTO getErrorInfo(ApiException ex){

        ErrorInfoDTO errorInfoDTO = new ErrorInfoDTO();
        Error err = ex.getError().getError();
        errorInfoDTO.setCode(err.getCode());
        String msg = err.getWhat();
        msg+="("+err.getCode()+")";
        if(err.getDetails().length>0){
            msg+="-"+err.getDetails()[0].getMessage();
        }
        errorInfoDTO.setMessage(msg);
        return  errorInfoDTO;
    }
}
