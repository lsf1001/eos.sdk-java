package eos.sdk.client.exception;


import lombok.Getter;
import lombok.Setter;

public class CryptoException extends RuntimeException {
	@Getter
	@Setter
	private String code;

	@Getter
	@Setter
	private String msg;

	private static final long serialVersionUID = 1L;

	public CryptoException(String code, String msg) {
		this.code = code;
		this.msg = msg;
	}
}