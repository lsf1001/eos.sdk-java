package eos.sdk.client.exception;

public class PackException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public PackException(String msg) {
		super(msg);
	}
}
