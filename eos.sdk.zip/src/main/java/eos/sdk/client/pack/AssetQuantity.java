package eos.sdk.client.pack;

import java.security.InvalidParameterException;

public class AssetQuantity {

	public static String parse(String quantity, String contractAccount) {
		String[] v = quantity.split(" ");
		if(v.length != 2) {
			throw new InvalidParameterException("quantity invalid");
		}

		if(contractAccount==null){
			contractAccount = "sys.token";
		}
		String amount = v[0];

		String ams [] = amount.split("[.]");
		int precision = 0;
		if(ams.length>1) {precision = ams[1].length();}

		String symbol = v[1];
		return String.format("%s %s,%s@%s", amount, precision, symbol, contractAccount);
	}
}
