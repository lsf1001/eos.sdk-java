package eos.sdk.client.pack;


import lombok.Getter;
import lombok.Setter;

public enum PackType {

	asset("asset"), 
	bytes("bytes"), 
	hexString("hexString"), 
	key("key"),
	pubkey("pubkey"),
	name("name"), 
	object("object"), 
	string("string"), 
	uint16("uint16"), 
	uint32("uint32"), 
	uint64("uint64"), 
	uint8("uint8"), 
	varint32("varint32"),
	Double("double");

	@Getter
	@Setter
	private String code;

	private PackType(String code) {
		this.code = code;
	}
}
