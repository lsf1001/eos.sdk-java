package eos.sdk.client.transaction;

import eos.sdk.SdkClient;
import eos.sdk.api.request.push_transaction.action.*;
import eos.sdk.api.request.push_transaction.action.*;
import eos.sdk.api.result.GetBlockResult;
import eos.sdk.api.result.GetInfoResults;
import eos.sdk.chain.action.Action;
import eos.sdk.chain.action.PermissionLevel;
import eos.sdk.chain.authority.Authority;
import eos.sdk.chain.authority.KeyWeight;
import eos.sdk.chain.authority.PermissionLevelWeight;
import eos.sdk.chain.authority.WaitWeight;
import eos.sdk.chain.transaction.Transaction;
import eos.sdk.client.exception.ApiException;
import eos.sdk.client.pack.AssetQuantity;
import eos.sdk.crypto.EccTool;
import eos.sdk.enums.AuthRightKindEnum;
import eos.sdk.utils.buskey.BusKeyUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class TransactionBuilder {

	private SdkClient sdkClient;

	private TransactionBuilder(SdkClient sdkClient) {
		this.sdkClient = sdkClient;
	}

	public static TransactionBuilder newInstance(SdkClient eosClient) {
		return new TransactionBuilder(eosClient);
	}

	public SignParam getSignParams() throws ApiException, IOException {
		SignParam params = new SignParam();
		GetInfoResults info = sdkClient.getChainInfo();
		// get block info
		GetBlockResult block = sdkClient.getBlock(info.getHeadBlockNum().toString());
		params.setChainId(info.getChainId());
		params.setHeadBlockTime(info.getHeadBlockTime());
		params.setHeadBlockId(info.getHeadBlockId());
		params.setExpiration(new Date(info.getHeadBlockTime().getTime() + 600 * 1000));
		params.setRefBlockNum(block.getBlockNum());
		params.setRefBlockPrefix(block.getRefBlockPrefix());
		params.setMaxNetUsageWords(0L);
		params.setMaxCpuUsageMs(0L);
		params.setDelaySec(0L);
		return params;
	}

	public SignedTransactionToPush buildNewAccountRawTx(SignParam param, String pk, String creator, String newAccount, String address, String owner,
			String active, Long buyRam, String stakeNetQuantity, String stakeCpuQuantity, Long transfer)
			throws IOException {
		return buildRawTx(param, pk, () -> {
			List<Action> actions = new ArrayList<>();
			// newaccount
			NewAccountActionData createMap = new NewAccountActionData();
			createMap.setCreator(creator);
			createMap.setName(newAccount);
			createMap.setAddress(address);
			createMap.setOwner(owner);
			createMap.setActive(active);
			Action createAction = new Action(creator, "eos", "newaccount", createMap);
			actions.add(createAction);
			// buyrambytes
			BuyrambytesActionData buyMap = new BuyrambytesActionData();
			buyMap.setPayer(creator);
			buyMap.setReceiver(newAccount);
			buyMap.setBytes(buyRam);
			Action buyAction = new Action(creator, "eos", "buyrambytes", buyMap);
			actions.add(buyAction);
			// delegatebw
			if (stakeNetQuantity != null && stakeCpuQuantity != null && transfer != null) {
				DelegatebwActionData delMap = new DelegatebwActionData();
				delMap.setFrom(creator);
				delMap.setReceiver(newAccount);
				delMap.setStakeNetQuantity(AssetQuantity.parse(stakeNetQuantity, "sys.token"));
				delMap.setStakeCpuQuantity(AssetQuantity.parse(stakeCpuQuantity, "sys.token"));
				delMap.setTransfer(transfer);
				Action delAction = new Action(creator, "eos", "delegatebw", delMap);
				actions.add(delAction);
			}
			return actions;
		});
	}

	public SignedTransactionToPush buildBuyramRawTx(SignParam param, String pk, String creator, String receiver, String quant)throws IOException {
		return buildRawTx(param, pk, () -> {
			List<Action> actions = new ArrayList<>();
			BuyramActionData buyMap = new BuyramActionData();
			buyMap.setPayer(creator);
			buyMap.setReceiver(receiver);
			buyMap.setQuant(AssetQuantity.parse(quant,null));
			Action buyAction = new Action(creator, "eos", "buyram", buyMap);
			actions.add(buyAction);
			return actions;
		});
	}
	
	public SignedTransactionToPush buildSellramRawTx(SignParam param, String pk, String account, Long sellRam)throws IOException {
		return buildRawTx(param, pk, () -> {
			List<Action> actions = new ArrayList<>();
			SellrambytesActionData sellMap = new SellrambytesActionData();
			sellMap.setAccount(account);
			sellMap.setBytes(sellRam);
			Action buyAction = new Action(account, "eos", "sellram", sellMap);
			actions.add(buyAction);
			return actions;
		});
	}

	public SignedTransactionToPush buildDelegatebwRawTx(SignParam param, String pk, String from, String receiver, String stakeNetQuantity, String stakeCpuQuantity, Long transfer)throws IOException {
		return buildRawTx(param, pk, () -> {
			List<Action> actions = new ArrayList<>();
			DelegatebwActionData delegatebwActionData = new DelegatebwActionData();
			delegatebwActionData.setFrom(from);
			delegatebwActionData.setReceiver(receiver);
			delegatebwActionData.setStakeNetQuantity(AssetQuantity.parse(stakeNetQuantity, "sys.token"));
			delegatebwActionData.setStakeCpuQuantity(AssetQuantity.parse(stakeCpuQuantity, "sys.token"));
			delegatebwActionData.setTransfer(transfer);
			Action buyAction = new Action(from, "eos", "delegatebw", delegatebwActionData);
			actions.add(buyAction);
			return actions;
		});
	}
	
	public SignedTransactionToPush buildUnDelegatebwRawTx(SignParam param, String pk, String from, String receiver, String stakeNetQuantity, String stakeCpuQuantity)throws IOException {
		return buildRawTx(param, pk, () -> {
			List<Action> actions = new ArrayList<>();
			UnDelegatebwActionData unDelegatebwActionData = new UnDelegatebwActionData();
			unDelegatebwActionData.setFrom(from);
			unDelegatebwActionData.setReceiver(receiver);
			unDelegatebwActionData.setStakeNetQuantity(AssetQuantity.parse(stakeNetQuantity, "sys.token"));
			unDelegatebwActionData.setStakeCpuQuantity(AssetQuantity.parse(stakeCpuQuantity, "sys.token"));
			Action buyAction = new Action(from, "eos", "undelegatebw", unDelegatebwActionData);
			actions.add(buyAction);
			return actions;
		});
	}

	private SignedTransactionToPush buildRawTx(SignParam param, String pk, ActionCollector actionCollector)
			throws ApiException {

			Transaction tx = new Transaction();
			tx.setExpiration(param.getExpiration());
			tx.setRefBlockNum(param.getRefBlockNum());
			tx.setRefBlockPrefix(param.getRefBlockPrefix());
			tx.setMaxNetUsageWords(param.getMaxNetUsageWords());
			tx.setMaxCpuUsageMs(param.getMaxCpuUsageMs());
			tx.setDelaySec(param.getDelaySec());
			// add actions
			List<Action> actions = actionCollector.collectActions();
			tx.setActions(actions);
			String sign = EccTool.signTransaction(pk, new TransactionToSign(param.getChainId(), tx));
			// txId1
			String txId = sdkClient.calcTransactionId(tx);
			// reset action data
			for (Action action : actions) {
				action.setData(action.getData().toString());
		}
		return new SignedTransactionToPush(txId, "none", tx, new String[] { sign });
	}

    private NeedSignedTransactionToPush buildNeedSignRawTx(SignParam param, ActionCollector actionCollector)
            throws ApiException {

        Transaction tx = new Transaction();
        tx.setExpiration(param.getExpiration());
        tx.setRefBlockNum(param.getRefBlockNum());
        tx.setRefBlockPrefix(param.getRefBlockPrefix());
        tx.setMaxNetUsageWords(param.getMaxNetUsageWords());
        tx.setMaxCpuUsageMs(param.getMaxCpuUsageMs());
        tx.setDelaySec(param.getDelaySec());
        // add actions
        List<Action> actions = actionCollector.collectActions();
        tx.setActions(actions);
		byte[] bytes = EccTool.byteToSignHash(new TransactionToSign(param.getChainId(), tx));
        // txId1
        String txId = sdkClient.calcTransactionId(tx);
        // reset action data
        for (Action action : actions) {
            action.setData(action.getData().toString());
        }
        return new NeedSignedTransactionToPush(txId, "none", tx, bytes);
    }

	public SignedTransactionToPush buildTransferRawTx(SignParam param, String pk, String contractAccount, String from, String to,
			String quantity, String memo) throws ApiException, IOException {
		return buildRawTx(param, pk, () -> {
			List<Action> actions = new ArrayList<>();
			TransferActionData dataMap = new TransferActionData();
			dataMap.setFrom(from);
			dataMap.setTo(to);
			dataMap.setQuantity(AssetQuantity.parse(quantity, contractAccount));
			dataMap.setMemo(memo);
			Action action = new Action(from, contractAccount, "transfer", dataMap);
			actions.add(action);
			return actions;
		});
	}

	public SignedTransactionToPush buildTransferExtRawTx(SignParam param, String pk, String contractAccount, String from, String fromAddress, String toAddress,
													  String quantity, String memo) throws ApiException, IOException {
		return buildRawTx(param, pk, () -> {
			List<Action> actions = new ArrayList<>();
			TransferExtActionData dataMap = new TransferExtActionData();
			dataMap.setFromAddress(fromAddress);
			dataMap.setToAddress(toAddress);
			dataMap.setQuantity(AssetQuantity.parse(quantity, contractAccount));
			dataMap.setMemo(memo);
			Action action = new Action(from, contractAccount, "transferext", dataMap);
			actions.add(action);
			return actions;
		});
	}

	public SignedTransactionToPush buildTransferExtWithMoreSignRawTx(SignParam param, String pk, String contractAccount, String from, String fromAddress, String toAddress,
														 String quantity, String memo) throws ApiException, IOException {
		return buildRawTx(param, pk, () -> {
			List<Action> actions = new ArrayList<>();
			TransferExtActionData dataMap = new TransferExtActionData();
			dataMap.setFromAddress(fromAddress);
			dataMap.setToAddress(toAddress);
			dataMap.setQuantity(AssetQuantity.parse(quantity, contractAccount));
			dataMap.setMemo(memo);
			Action action = new Action(from, contractAccount, "transferext", dataMap);
			List<PermissionLevel> authorization = action.getAuthorization();
			authorization.add(new PermissionLevel("needmoresign", "active"));
			action.setAuthorization(authorization);
			actions.add(action);
			return actions;
		});
	}

	public SignedTransactionToPush buildTransferExtWithMarkRawTx(SignParam param, String pk, String contractAccount, String from, String fromAddress, String toAddress,
														 String quantity, String memo, String mark) throws ApiException, IOException {
		return buildRawTx(param, pk, () -> {
			List<Action> actions = new ArrayList<>();
			TransferExtActionData dataMap = new TransferExtActionData();
			dataMap.setFromAddress(fromAddress);
			dataMap.setToAddress(toAddress);
			dataMap.setQuantity(AssetQuantity.parse(quantity, contractAccount));
			dataMap.setMemo(memo);
			Action action = new Action(from, contractAccount, "transferext", dataMap);
			actions.add(action);

			AddMarkActionData addMarkDataMap = new AddMarkActionData();
			addMarkDataMap.setOwner(from);
			addMarkDataMap.setMark(mark);
			Action addMarkAction = new Action(from, contractAccount, "addmark", addMarkDataMap);
			actions.add(addMarkAction);
			return actions;
		});
	}

	public String buildTransferExtBin(String contractAccount, String from, String fromAddress, String toAddress,
														 String quantity, String memo) throws ApiException, IOException {
		TransferExtActionData dataMap = new TransferExtActionData();
		dataMap.setFromAddress(fromAddress);
		dataMap.setToAddress(toAddress);
		dataMap.setQuantity(AssetQuantity.parse(quantity, contractAccount));
		dataMap.setMemo((memo != null && memo.length() != 0) ? memo : "" );
		Action action = new Action(from, contractAccount, "transferext", dataMap);
		return action.getData().toString();
	}

    public SignedTransactionToPush buildTransferExtWithFeeRawTx(SignParam param, String pk, String contractAccount, String from, String fromAddress, String toAddress,
                                                         String quantity, String memo, String quantityFee) throws ApiException, IOException {
        return buildRawTx(param, pk, () -> {
            List<Action> actions = new ArrayList<>();
			TransferActionData dataMapTransfer = new TransferActionData();
			dataMapTransfer.setFrom(from);
			dataMapTransfer.setTo("sys.fee");
			dataMapTransfer.setQuantity(AssetQuantity.parse(quantityFee, "sys.token"));
			dataMapTransfer.setMemo(memo);
			Action actionTransfer = new Action(from, "sys.token", "transfer", dataMapTransfer);
			actions.add(actionTransfer);

            TransferExtActionData dataMapTransferExt = new TransferExtActionData();
			dataMapTransferExt.setFromAddress(fromAddress);
			dataMapTransferExt.setToAddress(toAddress);
			dataMapTransferExt.setQuantity(AssetQuantity.parse(quantity, contractAccount));
			dataMapTransferExt.setMemo(memo);
            Action actionTransferExt = new Action(from, contractAccount, "transferext", dataMapTransferExt);
            actions.add(actionTransferExt);
            return actions;
        });
    }

	public SignedTransactionToPush buildAddHdAddressRawTx(SignParam param, String pk, String contractAccount, String account, String address) throws ApiException, IOException {
		return buildRawTx(param, pk, () -> {
			List<Action> actions = new ArrayList<>();
			AddHdAddressActionData dataMap = new AddHdAddressActionData();
			dataMap.setAccount(account);
			dataMap.setAddress(address);
			Action action = new Action("sys.auth", contractAccount, "addhdaddress", dataMap);
			actions.add(action);
			return actions;
		});
	}
	
	public SignedTransactionToPush buildAddHdAddressRawTxList(SignParam param, String pk, String contractAccount, String account, List<String> addressList) throws ApiException, IOException {
		return buildRawTx(param, pk, () -> {
			List<Action> actions = new ArrayList<>();
			for (int i = 0; i < addressList.size(); i++) {
				AddHdAddressActionData dataMap = new AddHdAddressActionData();
				dataMap.setAccount(account);
				dataMap.setAddress(addressList.get(i));
				Action action = new Action("sys.auth", contractAccount, "addhdaddress", dataMap);
				actions.add(action);
			}
			return actions;
		});
	}

	public SignedTransactionToPush buildAddAttachPermissionRawTx(SignParam param, String pk, String account, String permission, String parent, String publicKey, String codeAccount,  String codePermission) throws ApiException, IOException {
		return buildRawTx(param, pk, () -> {
			List<Action> actions = new ArrayList<>();
			actions.add(addAttachPermission(account, permission, parent, publicKey, codeAccount, codePermission));
			return actions;
		});
	}

	public SignedTransactionToPush buildRemoveAttachPermissionRawTx(SignParam param, String pk, String account, String permission, String parent, String publicKey) throws ApiException, IOException {
		return buildRawTx(param, pk, () -> {
			List<Action> actions = new ArrayList<>();
			actions.add(removeAttachPermission(account, permission, parent, publicKey));
			return actions;
		});
	}

	public SignedTransactionToPush buildAddNewPermissionRawTx(SignParam param, String pk, String account, String permission, String parent, String publicKey) throws ApiException, IOException {
		return buildRawTx(param, pk, () -> {
			List<Action> actions = new ArrayList<>();
			actions.add(addNewPermission(account, permission, parent, publicKey));
			return actions;
		});
	}

	public SignedTransactionToPush buildDeletePermissionRawTx(SignParam param, String pk, String account, String permission) throws ApiException, IOException {
		return buildRawTx(param, pk, () -> {
			List<Action> actions = new ArrayList<>();
			actions.add(deletePermission(account, permission));
			return actions;
		});
	}

	public SignedTransactionToPush buildVoteProducerRawTx(SignParam param, String pk, String voter, String proxy, List<String> producers)
			throws ApiException, IOException {
		return buildRawTx(param, pk, () -> {
			producers.sort((h1, h2) -> h1.compareTo(h2));
			List<Action> actions = new ArrayList<>();
			VoteProducerActionData data = new VoteProducerActionData();
			data.setVoter(voter);
			data.setProxy(proxy);
			data.setProducers(producers);
			Action action = new Action(voter, "eos", "voteproducer", data);
			actions.add(action);
			return actions;
		});
	}

	public SignedTransactionToPush buildLinkAuthRawTx(SignParam param, String pk, String account, String code, String type, String requirement)
			throws ApiException, IOException {
		return buildRawTx(param, pk, () -> {
			List<Action> actions = new ArrayList<>();
			LinkAuthActionData data = new LinkAuthActionData();
			data.setAccount(account);
			data.setCode(code);
			data.setType(type);
			data.setRequirement(requirement);
			Action action = new Action(account, "eos", "linkauth", data);
			actions.add(action);
			return actions;
		});
	}

	public SignedTransactionToPush buildUnLinkAuthRawTx(SignParam param, String pk, String account, String code, String type)
			throws ApiException, IOException {
		return buildRawTx(param, pk, () -> {
			List<Action> actions = new ArrayList<>();
			UnLinkAuthActionData data = new UnLinkAuthActionData();
			data.setAccount(account);
			data.setCode(code);
			data.setType(type);
			Action action = new Action(account, "eos", "unlinkauth", data);
			actions.add(action);
			return actions;
		});
	}

	private List<Action> makeApplyIssueActions(String account, String publicKey){
        List<Action> actions = new ArrayList<>();
        actions.add(addAttachPermission(account, "share", "active", publicKey, "sys.auth", "active"));

        LinkAuthActionData dataCode = new LinkAuthActionData();
        dataCode.setAccount(account);
        dataCode.setCode("eos");
        dataCode.setType("setcode");
        dataCode.setRequirement("share");
        actions.add(new Action(account, "eos", "linkauth", dataCode));

        LinkAuthActionData dataAbi = new LinkAuthActionData();
        dataAbi.setAccount(account);
        dataAbi.setCode("eos");
        dataAbi.setType("setabi");
        dataAbi.setRequirement("share");
        actions.add(new Action(account, "eos", "linkauth", dataAbi));

        LinkAuthActionData dataCreate = new LinkAuthActionData();
        dataCreate.setAccount(account);
        dataCreate.setCode(account);
        dataCreate.setType("create");
        dataCreate.setRequirement("share");
        actions.add(new Action(account, "eos", "linkauth", dataCreate));

        LinkAuthActionData dataIssue = new LinkAuthActionData();
        dataIssue.setAccount(account);
        dataIssue.setCode(account);
        dataIssue.setType("issue");
        dataIssue.setRequirement("share");
        actions.add(new Action(account, "eos", "linkauth", dataIssue));

        LinkAuthActionData dataRetire = new LinkAuthActionData();
        dataRetire.setAccount(account);
        dataRetire.setCode(account);
        dataRetire.setType("retire");
        dataRetire.setRequirement("share");
        actions.add(new Action(account, "eos", "linkauth", dataRetire));

        LinkAuthActionData dataTransfer = new LinkAuthActionData();
        dataTransfer.setAccount(account);
        dataTransfer.setCode(account);
        dataTransfer.setType("transfer");
        dataTransfer.setRequirement("share");
        actions.add(new Action(account, "eos", "linkauth", dataTransfer));

        LinkAuthActionData dataOpen = new LinkAuthActionData();
        dataOpen.setAccount(account);
        dataOpen.setCode(account);
        dataOpen.setType("open");
        dataOpen.setRequirement("share");
        actions.add(new Action(account, "eos", "linkauth", dataOpen));

        LinkAuthActionData dataClose = new LinkAuthActionData();
        dataClose.setAccount(account);
        dataClose.setCode(account);
        dataClose.setType("close");
        dataClose.setRequirement("share");
        actions.add(new Action(account, "eos", "linkauth", dataClose));

        return actions;
    }

	public SignedTransactionToPush buildApplyIssueRawTx(SignParam param, String pk, String account)
			throws ApiException {
        return buildRawTx(param, pk, () -> makeApplyIssueActions(account, BusKeyUtils.getPublicKey(pk)));
	}

    public NeedSignedTransactionToPush buildNeedSignApplyIssueRawTx(SignParam param, String account)
            throws ApiException {
        return buildNeedSignRawTx(param, () -> makeApplyIssueActions(account, ""));
    }

    private List<Action> makeUnApplyIssueActions(String account){
        List<Action> actions = new ArrayList<>();

        UnLinkAuthActionData dataCode = new UnLinkAuthActionData();
        dataCode.setAccount(account);
        dataCode.setCode("eos");
        dataCode.setType("setcode");
        actions.add(new Action(account, "eos", "unlinkauth", dataCode));

        UnLinkAuthActionData dataAbi = new UnLinkAuthActionData();
        dataAbi.setAccount(account);
        dataAbi.setCode("eos");
        dataAbi.setType("setabi");
        actions.add(new Action(account, "eos", "unlinkauth", dataAbi));

        UnLinkAuthActionData dataCreate = new UnLinkAuthActionData();
        dataCreate.setAccount(account);
        dataCreate.setCode(account);
        dataCreate.setType("create");
        actions.add(new Action(account, "eos", "unlinkauth", dataCreate));

        UnLinkAuthActionData dataIssue = new UnLinkAuthActionData();
        dataIssue.setAccount(account);
        dataIssue.setCode(account);
        dataIssue.setType("issue");
        actions.add(new Action(account, "eos", "unlinkauth", dataIssue));

        UnLinkAuthActionData dataRetire = new UnLinkAuthActionData();
        dataRetire.setAccount(account);
        dataRetire.setCode(account);
        dataRetire.setType("retire");
        actions.add(new Action(account, "eos", "unlinkauth", dataRetire));

        UnLinkAuthActionData dataTransfer = new UnLinkAuthActionData();
        dataTransfer.setAccount(account);
        dataTransfer.setCode(account);
        dataTransfer.setType("transfer");
        actions.add(new Action(account, "eos", "unlinkauth", dataTransfer));

        UnLinkAuthActionData dataOpen = new UnLinkAuthActionData();
        dataOpen.setAccount(account);
        dataOpen.setCode(account);
        dataOpen.setType("open");
        actions.add(new Action(account, "eos", "unlinkauth", dataOpen));

        UnLinkAuthActionData dataClose = new UnLinkAuthActionData();
        dataClose.setAccount(account);
        dataClose.setCode(account);
        dataClose.setType("close");
        actions.add(new Action(account, "eos", "unlinkauth", dataClose));

        actions.add(deletePermission(account, "share"));
        return actions;
    }

	public SignedTransactionToPush buildUnApplyIssueRawTx(SignParam param, String pk, String account)
			throws ApiException {
		return buildRawTx(param, pk, () -> makeUnApplyIssueActions(account));
	}

    public NeedSignedTransactionToPush buildNeedSignUnApplyIssueRawTx(SignParam param, String account)
            throws ApiException {
        return buildNeedSignRawTx(param, () -> makeUnApplyIssueActions(account));
    }

	private Action makeUpdateAuthAction(String account, String permission, String parent, Authority authority) {
		UpdateAuthActionData data = new UpdateAuthActionData();
		data.setAccount(account);
		data.setPermission(permission);
		data.setParent(parent);
		data.setAuth(authority);
		return new Action(account, "eos", "updateauth", data);
	}

	private Action makeUpdateAttachPermission(String account, String permission, String parent, String publicKey, ArrayList<PermissionLevelWeight> al) {
		Authority authority = new Authority();
		authority.setThreshold(1L);
		authority.setAccounts(al);

		List<KeyWeight> keys = new ArrayList<>();
		if(!publicKey.isEmpty()) {
			KeyWeight keyWeight = new KeyWeight();
			keyWeight.setWeight(1L);
			keyWeight.setKey(publicKey);
			keys.add(keyWeight);
		}
		authority.setKeys(keys);

		List<WaitWeight> waitWeights = new ArrayList<>();
		authority.setWaits(waitWeights);
		return makeUpdateAuthAction(account, permission, parent, authority);
	}
	
	private Action removeAttachPermission(String account, String permission, String parent, String publicKey) {
		ArrayList<PermissionLevelWeight> al = new ArrayList<>();
		return makeUpdateAttachPermission(account, permission, parent, publicKey, al);
	}

	private Action addNewPermission(String account, String permission, String parent, String publicKey) {
		return removeAttachPermission(account, permission, parent, publicKey);
	}

	private Action deletePermission(String account, String permission) {
		DeleteAuthActionData data = new DeleteAuthActionData();
		data.setAccount(account);
		data.setPermission(permission);
		return new Action(account, "eos", "deleteauth", data);
	}

	private Action addAttachPermission(String account, String permission, String parent, String publicKey, String codeAccount,  String codePermission) {
		ArrayList<PermissionLevelWeight> al = new ArrayList<>();
		PermissionLevelWeight permissionLevelWeight = new PermissionLevelWeight();
		permissionLevelWeight.setWeight(1L);

		PermissionLevel permissionLevel = new PermissionLevel();
		permissionLevel.setActor(codeAccount);
		permissionLevel.setPermission(codePermission);

		permissionLevelWeight.setPermission(permissionLevel);
		al.add(permissionLevelWeight);
		return makeUpdateAttachPermission(account, permission, parent, publicKey, al);
	}

	public SignedTransactionToPush buildUpdateUserAuthKeyRawTx(SignParam param, String pk, String actor, String kind, String newPublicKey)
			throws ApiException, IOException {
		return buildRawTx(param, pk, () -> {
			List<Action> actions = new ArrayList<>();
			UpdateAuthActionData data = new UpdateAuthActionData();
			data.setAccount(actor);
			String permission;
			if (kind.equals(AuthRightKindEnum.OWNER.getCode())) {
				data.setPermission("owner");
				data.setParent("");
				permission = "owner";
			} else {
				data.setPermission("active");
				data.setParent("owner");
				permission = "active";
			}
			Authority authority = new Authority();
			authority.setThreshold(1L);
			List<PermissionLevelWeight> al = new ArrayList<>();
			authority.setAccounts(al);
			List<KeyWeight> keys = new ArrayList<>();
			KeyWeight keyWeight = new KeyWeight();
			keyWeight.setWeight(1L);
			keyWeight.setKey(newPublicKey);
			keys.add(keyWeight);
			authority.setKeys(keys);
			List<WaitWeight> waitWeights = new ArrayList<>();
			authority.setWaits(waitWeights);
			data.setAuth(authority);
			Action action = new Action(actor, "eos", "updateauth", data, permission);
			actions.add(action);
			return actions;
		});
	}
	
	public SignedTransactionToPush buildNeedMoreSign(SignParam param, String pk, String account, String method)
			throws ApiException, IOException {
		return buildRawTx(param, pk, () -> {
			List<Action> actions = new ArrayList<>();
			OneOwner dataMap = new OneOwner();
			dataMap.setOwner(account);
			Action action = new Action("sys.auth", "sys.token", method, dataMap);
			actions.add(action);
			return actions;
		});
	}
	
	public SignedTransactionToPush buildCollect(SignParam param, String pk, String bpName, String method)
			throws ApiException, IOException {
		return buildRawTx(param, pk, () -> {
			List<Action> actions = new ArrayList<>();
			Collect dataMap = new Collect();
			dataMap.setCollectedName(bpName);
			Action action = new Action("sys.auth", "sys.collect", method, dataMap);
			actions.add(action);
			return actions;
		});
	}
}
