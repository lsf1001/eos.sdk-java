package eos.sdk.client.transaction;

import java.util.List;

import eos.sdk.chain.action.Action;

public interface ActionCollector {
	public List<Action> collectActions();
}
