package eos.sdk.client.transaction;

import eos.sdk.chain.transaction.Transaction;
import lombok.Getter;
import lombok.Setter;


public class NeedSignedTransactionToPush {
	@Getter
	@Setter
	private String txId;

	@Getter
	@Setter
	private String compression;

	@Getter
	@Setter
	private Transaction transaction;

	@Getter
	@Setter
	private byte[] byteToSignHash;
	
	public NeedSignedTransactionToPush() {
		
	}
	
	public NeedSignedTransactionToPush(String txId, String compression, Transaction transaction, byte[] byteToSignHash) {
		this.txId = txId;
		this.compression = compression;
		this.transaction = transaction;
		this.byteToSignHash = byteToSignHash;
	}
}
