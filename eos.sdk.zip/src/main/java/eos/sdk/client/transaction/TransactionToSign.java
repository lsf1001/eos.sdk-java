package eos.sdk.client.transaction;

import eos.sdk.chain.transaction.Transaction;
import eos.sdk.client.pack.Pack;
import eos.sdk.client.pack.PackType;
import lombok.Getter;
import lombok.Setter;


public class TransactionToSign {
	@Pack(PackType.hexString)
	@Getter
	@Setter
	private String chainId;
	
	@Pack
	@Getter
	@Setter
	private Transaction transaction;
	
	public TransactionToSign() {

	}

	public TransactionToSign(String chainId, Transaction transaction) {
		this.chainId = chainId;
		this.transaction = transaction;
	}
}
