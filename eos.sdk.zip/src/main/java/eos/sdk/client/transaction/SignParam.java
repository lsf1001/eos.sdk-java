package eos.sdk.client.transaction;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;

public class SignParam {
    @Getter
    @Setter
    private String chainId;

    @Getter
    @Setter
    private Date expiration;

    @Getter
    @Setter
    private Date headBlockTime;

    @Getter
    @Setter
    private String headBlockId;

    @Getter
    @Setter
    private Long refBlockNum;

    @Getter
    @Setter
    private Long refBlockPrefix;

    @Getter
    @Setter
    private Long maxNetUsageWords;

    @Getter
    @Setter
    private Long maxCpuUsageMs;

    @Getter
    @Setter
    private Long delaySec;
}
