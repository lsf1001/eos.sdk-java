package eos.sdk.client.transaction;

import eos.sdk.chain.transaction.Transaction;
import lombok.Getter;
import lombok.Setter;


public class SignedTransactionToPush {
	@Getter
	@Setter
	private String txId;

	@Getter
	@Setter
	private String compression;

	@Getter
	@Setter
	private Transaction transaction;

	@Getter
	@Setter
	private String[] signatures;
	
	public SignedTransactionToPush() {
		
	}
	
	public SignedTransactionToPush(String txId, String compression, Transaction transaction, String[] signatures) {
		this.txId = txId;
		this.compression = compression;
		this.transaction = transaction;
		this.signatures = signatures;
	}
}
