package eos.sdk.dto;

import lombok.Data;


@Data
public class ErrorInfoDTO {
    private String code;

    private String message;
}
