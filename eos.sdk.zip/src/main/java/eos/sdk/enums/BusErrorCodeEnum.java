package eos.sdk.enums;

import lombok.Getter;
import lombok.Setter;

public enum BusErrorCodeEnum {

    Expired_Transaction("3040005","交易过期，过期时间可以设置长一点"),
    ;
    @Getter
    @Setter
    private String code;

    @Getter
    @Setter
    private String msg;

    BusErrorCodeEnum(String code, String msg) {
        this.code = code;
        this.msg = msg;
    }
}
