package eos.sdk.enums;

import lombok.Getter;
import lombok.Setter;

public enum AuthRightKindEnum {

    OWNER("owner"),
    ACTIVE("active"),
    ;
    @Getter
    @Setter
    private String code;

    AuthRightKindEnum(String code) {
        this.code = code;
    }
}
