package eos.sdk.chain.authority;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import eos.sdk.client.pack.Pack;
import eos.sdk.client.pack.PackType;
import eos.sdk.chain.action.PermissionLevel;
import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PermissionLevelWeight  {
	@Pack
	@JsonProperty("permission")
	@Getter
	@Setter
	private PermissionLevel permission;

	@Pack(PackType.uint16)
	@JsonProperty("weight")
	@Getter
	@Setter
	private Long weight;
}
