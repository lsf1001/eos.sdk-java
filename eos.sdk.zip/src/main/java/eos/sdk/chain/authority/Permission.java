package eos.sdk.chain.authority;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;


@JsonIgnoreProperties(ignoreUnknown = true)
public class Permission {
	@JsonProperty("perm_name")
	@Getter
	@Setter
	private String permName;

	@JsonProperty("parent")
	private String parent;

	@JsonProperty("required_auth")
	private Authority requiredAuth;
}
