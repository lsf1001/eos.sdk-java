package eos.sdk.chain.authority;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import eos.sdk.client.pack.Pack;
import eos.sdk.client.pack.PackType;
import lombok.Getter;
import lombok.Setter;


@JsonIgnoreProperties(ignoreUnknown = true)
public class KeyWeight {

	@Pack(PackType.pubkey)
	@JsonProperty("key")
	@Getter
	@Setter
	private String key;

	@Pack(PackType.uint16)
	@JsonProperty("weight")
	@Getter
	@Setter
	private Long weight;

	public KeyWeight() {

	}
}
