package eos.sdk.chain.authority;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import eos.sdk.client.pack.Pack;
import eos.sdk.client.pack.PackType;
import lombok.Getter;
import lombok.Setter;


@JsonIgnoreProperties(ignoreUnknown = true)
public class WaitWeight  {
	@Pack(PackType.uint32)
	@JsonProperty("wait_sec")
	@Getter
	@Setter
	private Long waitSec;

	@Pack(PackType.uint16)
	@JsonProperty("weight")
	@Getter
	@Setter
	private Long weight;
}
