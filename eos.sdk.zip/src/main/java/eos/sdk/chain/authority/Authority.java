package eos.sdk.chain.authority;

import eos.sdk.client.pack.Pack;
import eos.sdk.client.pack.PackType;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;


@JsonIgnoreProperties(ignoreUnknown = true)
public class Authority  {

	@Pack(PackType.uint32)
	@JsonProperty("threshold")
	@Getter
	@Setter
	private Long threshold;

	@Pack
	@JsonProperty("keys")
	@Getter
	@Setter
	private List<KeyWeight> keys;

	@Pack
	@JsonProperty("accounts")
	@Getter
	@Setter
	private List<PermissionLevelWeight> accounts;

	@Pack
	@JsonProperty("waits")
	@Getter
	@Setter
	private List<WaitWeight> waits;
}
