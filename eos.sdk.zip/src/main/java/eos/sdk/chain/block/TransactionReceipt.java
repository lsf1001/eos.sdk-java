package eos.sdk.chain.block;

import eos.sdk.chain.transaction.PackedTransaction;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;


@JsonIgnoreProperties(ignoreUnknown = true)
public class TransactionReceipt<T extends PackedTransaction> extends TransactionReceiptHeader {
	@JsonProperty("trx")
	@Getter
	@Setter
	private T trx;
}
