package eos.sdk.chain.block;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
public class TransactionReceiptHeader {
	@JsonProperty("status")
	@Getter
	@Setter
	private String status;

	@JsonProperty("cpu_usage_us")
	@Getter
	@Setter
	private Long cpuUsageUs;

	@JsonProperty("net_usage_words")
	@Getter
	@Setter
	private Long netUsageWords;
}
