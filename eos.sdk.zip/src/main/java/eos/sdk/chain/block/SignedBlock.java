package eos.sdk.chain.block;

import eos.sdk.chain.Extensions;
import eos.sdk.chain.block_header.SignedBlockHeader;
import eos.sdk.chain.transaction.PackedTransaction;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;


@JsonIgnoreProperties(ignoreUnknown = true)
public class SignedBlock<T extends TransactionReceipt<? extends PackedTransaction>> extends SignedBlockHeader {
	@JsonProperty("transactions")
	@Getter
	@Setter
	private List<T> transactions;

	@JsonProperty("block_extensions")
	@Getter
	@Setter
	private List<Extensions> blockExtensions;
}
