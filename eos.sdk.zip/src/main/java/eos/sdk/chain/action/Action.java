package eos.sdk.chain.action;

import eos.sdk.client.pack.Pack;
import eos.sdk.client.pack.PackType;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.ArrayList;
import java.util.List;


@JsonIgnoreProperties(ignoreUnknown = true)
public class Action {
	@Pack(PackType.name)
	@JsonProperty("account")
	@Getter
	@Setter
	private String account;

	@Pack(PackType.name)
	@JsonProperty("name")
	@Getter
	@Setter
	private String name;

	@Pack
	@JsonProperty("authorization")
	@Getter
	@Setter
	private List<PermissionLevel> authorization;

	@Pack(PackType.bytes)
	@JsonProperty("data")
	@Getter
	@Setter
	private Object data;
	
	@JsonProperty("hex_data")
	@Getter
	@Setter
	private String hexData;

	public Action() {

	}

	public Action(String actor, String account, String name, Object data) {
		this.account = account;
		this.name = name;
		this.data = data;
		this.authorization = new ArrayList<>();
		this.authorization.add(new PermissionLevel(actor, "active"));
	}

	public Action(String actor, String account, String name, Object data, String permission) {
		this.account = account;
		this.name = name;
		this.data = data;
		this.authorization = new ArrayList<>();
		this.authorization.add(new PermissionLevel(actor, permission));
	}
}
