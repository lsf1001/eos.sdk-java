package eos.sdk.chain.action;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import eos.sdk.client.pack.Pack;
import eos.sdk.client.pack.PackType;
import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ActionNotice extends Action {
	@Pack(PackType.name)
	@JsonProperty("receiver")
	@Getter
	@Setter
	private String receiver;
}
