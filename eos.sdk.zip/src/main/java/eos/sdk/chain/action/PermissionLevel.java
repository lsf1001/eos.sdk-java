package eos.sdk.chain.action;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import eos.sdk.client.pack.Pack;
import eos.sdk.client.pack.PackType;
import lombok.Getter;
import lombok.Setter;


@JsonIgnoreProperties(ignoreUnknown = true)
public class PermissionLevel {
	
	@Pack(PackType.name)
	@JsonProperty("actor")
	@Getter
	@Setter
	private String actor;
	
	@Pack(PackType.name)
	@JsonProperty("permission")
	@Getter
	@Setter
	private String permission;

	public PermissionLevel() {
		
	}

	public PermissionLevel(String actor, String permission) {
		this.actor = actor;
		this.permission = permission;
	}
}
