package eos.sdk.chain.block_header;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SignedBlockHeader extends BlockHeader {
	@JsonProperty("producer_signature")
	@Getter
	@Setter
	private String producerSignature;
}
