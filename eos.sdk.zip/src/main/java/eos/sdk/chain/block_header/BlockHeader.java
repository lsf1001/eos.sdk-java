package eos.sdk.chain.block_header;

import eos.sdk.chain.Extensions;
import eos.sdk.chain.producer.ProducerSchedule;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;
import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class BlockHeader {
	@JsonProperty("timestamp")
	@JsonFormat(pattern="yyyy-MM-dd'T'HH:mm:ss.SSS")
	@Getter
	@Setter
	private Date timestamp;

	@JsonProperty("producer")
	@Getter
	@Setter
	private String producer;

	@JsonProperty("confirmed")
	@Getter
	@Setter
	private Long confirmed;

	@JsonProperty("previous")
	@Getter
	@Setter
	private String previous;

	@JsonProperty("transaction_mroot")
	@Getter
	@Setter
	private String transactionMroot;

	@JsonProperty("action_mroot")
	@Getter
	@Setter
	private String actionMroot;

	@JsonProperty("schedule_version")
	@Getter
	@Setter
	private String scheduleVersion;
	
	@JsonProperty("new_producers")
	@Getter
	@Setter
	private ProducerSchedule newProducers;
	
	@JsonProperty("header_extensions")
	@Getter
	@Setter
	private List<Extensions> headerExtensions;
}
