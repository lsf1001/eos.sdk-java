package eos.sdk.chain.trace;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import eos.sdk.chain.ActionReciept;
import eos.sdk.chain.action.Action;
import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
public class BaseActionTrace {
	@JsonProperty("receipt")
	@Getter
	@Setter
	private ActionReciept receipt;

	@JsonProperty("act")
	@Getter
	@Setter
	private Action act;

	@JsonProperty("elapsed")
	@Getter
	@Setter
	private Long elapsed;

	@JsonProperty("cpu_usage")
	@Getter
	@Setter
	private Long cpuUsage;

	@JsonProperty("console")
	@Getter
	@Setter
	private String console;

	@JsonProperty("total_cpu_usage")
	@Getter
	@Setter
	private Long totalCpuUsage;

	@JsonProperty("trx_id")
	@Getter
	@Setter
	private String trxId;
}
