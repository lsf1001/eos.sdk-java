package eos.sdk.chain.trace;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ActionTrace extends BaseActionTrace {
	@JsonProperty("inline_traces")
	@Getter
	@Setter
	private List<ActionTrace> inlineTraces;

	@JsonProperty("console")
	@Getter
	@Setter
	private String console;
}
