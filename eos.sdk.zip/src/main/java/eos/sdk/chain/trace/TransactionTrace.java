package eos.sdk.chain.trace;

import eos.sdk.chain.block.TransactionReceiptHeader;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;


@JsonIgnoreProperties(ignoreUnknown = true)
public class TransactionTrace {
	@JsonProperty("id")
	@Getter
	@Setter
	private String id;

	@JsonProperty("block_num")
	@Getter
	@Setter
	private Long blockNum;

	@JsonProperty("receipt")
	@Getter
	@Setter
	private TransactionReceiptHeader receipt;

	@JsonProperty("elapsed")
	@Getter
	@Setter
	private Long elapsed;

	@JsonProperty("net_usage")
	@Getter
	@Setter
	private Long netUsage;

	@JsonProperty("scheduled")
	@Getter
	@Setter
	private Boolean scheduled;

	@JsonProperty("action_traces")
	@Getter
	@Setter
	private List<ActionTrace> actionTraces;
	
	@JsonProperty("except")
	@Getter
	@Setter
	private Object except;
}
