package eos.sdk.chain.producer;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ProducerKey {
	@JsonProperty("producer_name")
	@Getter
	@Setter
	private String producerName;
	
	@JsonProperty("block_signing_key")
	@Getter
	@Setter
	private String blockSigningKey;
}
