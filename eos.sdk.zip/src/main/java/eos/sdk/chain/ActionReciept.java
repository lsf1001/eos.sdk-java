package eos.sdk.chain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ActionReciept {
	@JsonProperty("receiver")
	@Getter
	@Setter
	private String receiver;

	@JsonProperty("act_digest")
	@Getter
	@Setter
	private String actDigest;

	@JsonProperty("global_sequence")
	@Getter
	@Setter
	private Long globalSequence;

	@JsonProperty("recv_sequence")
	@Getter
	@Setter
	private Long recvSequence;

	@JsonProperty("auth_sequence")
	@Getter
	@Setter
	private List<Object> authSequence;

	@JsonProperty("code_sequence")
	@Getter
	@Setter
	private Long codeSequence;

	@JsonProperty("abi_sequence")
	@Getter
	@Setter
	private Long abiSequence;
}
