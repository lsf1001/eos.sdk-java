package eos.sdk.chain.transaction;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class SignedTransaction extends Transaction {
	@JsonProperty("signatures")
	@Getter
	@Setter
	private List<String> signatures;
	
	@JsonProperty("context_free_data")
	@Getter
	@Setter
	private List<Object> contextFreeData;
}
