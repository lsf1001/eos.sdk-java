package eos.sdk.chain.transaction;

import eos.sdk.client.pack.Pack;
import eos.sdk.client.pack.PackType;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@JsonIgnoreProperties(ignoreUnknown = true)
public class TransactionHeader {
	@Pack(PackType.uint32)
	@JsonProperty("expiration")
	@JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss")
	@Getter
	@Setter
	private Date expiration;
	
	@Pack(PackType.uint16)
	@JsonProperty("ref_block_num")
	@Getter
	@Setter
	private Long refBlockNum;
	
	@Pack(PackType.uint32)
	@JsonProperty("ref_block_prefix")
	@Getter
	@Setter
	private Long refBlockPrefix;

	@Pack(PackType.varint32)
	@JsonProperty("max_net_usage_words")
	@Getter
	@Setter
	private Long maxNetUsageWords;

	@Pack(PackType.uint8)
	@JsonProperty("max_cpu_usage_ms")
	@Getter
	@Setter
	private Long maxCpuUsageMs;

	@Pack(PackType.varint32)
	@JsonProperty("delay_sec")
	@Getter
	@Setter
	private Long delaySec;
}
