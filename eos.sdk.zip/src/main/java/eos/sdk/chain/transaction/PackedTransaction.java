package eos.sdk.chain.transaction;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class PackedTransaction {
	
	private boolean isNumber = false;
	private boolean isTxId = false;
	private String txId;
	
	@JsonProperty("signatures")
	@Getter
	@Setter
	private List<String> signatures;

	@JsonProperty("compression")
	@Getter
	@Setter
	private String compression;

	@JsonProperty("packed_context_free_data")
	@Getter
	@Setter
	private String packedContextFreeData;

	@JsonProperty("packed_trx")
	@Getter
	@Setter
	private String packedTrx;

	public PackedTransaction() {
	}

	public PackedTransaction(String txId) {
		this.txId = txId;
		isTxId = true;
	}
}
