package eos.sdk.chain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;


@JsonIgnoreProperties(ignoreUnknown = true)
public class AccountResourceLimit {
	@JsonProperty("used")
	@Getter
	@Setter
	private Long used;

	@JsonProperty("available")
	@Getter
	@Setter
	private Long available;
	
	@JsonProperty("max")
	@Getter
	@Setter
	private Long max;
}
