package eos.sdk;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import eos.sdk.api.request.*;
import eos.sdk.api.result.*;
import eos.sdk.api.request.*;
import eos.sdk.api.result.*;
import eos.sdk.api.service.RpcService;
import eos.sdk.chain.transaction.Transaction;
import eos.sdk.client.exception.ApiException;
import eos.sdk.client.exception.InvalidParameterException;
import eos.sdk.client.http.Generator;
import eos.sdk.client.pack.PackUtils;
import eos.sdk.client.transaction.SignedTransactionToPush;
import eos.sdk.client.transaction.TransactionBuilder;
import eos.sdk.crypto.util.Sha;
import eos.sdk.utils.BusUtil;
import eos.sdk.utils.ByteBuffer;
import eos.sdk.utils.Hex;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class SdkClient {
	private RpcService rpcService;
	private TransactionBuilder txBuilder;

	public SdkClient(String baseUrl) {
		this(baseUrl, null);
	}

	public SdkClient(String baseUrl, String host) {
		if(baseUrl != null && !baseUrl.isEmpty()){
			rpcService = Generator.createService(RpcService.class, baseUrl, host);
		}
		txBuilder = TransactionBuilder.newInstance(this);
	}

	public TransactionBuilder txBuilder() {
		return txBuilder;
	}

	public String calcTransactionId(Transaction transaction) {
		ByteBuffer bf = new ByteBuffer();
		PackUtils.packObj(transaction, bf);
		return Hex.bytesToHexString(Sha.SHA256(bf.getBuffer()));
	}

	public PushTransactionResults createAccount(String pk, String creator, String newAccount, String address, String owner,
												String active, Long buyRam) throws ApiException, IOException {
		return createAccount(pk, creator, newAccount, address, owner, active, buyRam, null, null, null);
	}

	public PushTransactionResults createAccount(String pk, String creator, String newAccount, String address, String owner,
												String active, Long buyRam, String stakeNetQuantity, String stakeCpuQuantity, Long transfer)
			throws ApiException, IOException {
		return pushTransaction(txBuilder.buildNewAccountRawTx(txBuilder.getSignParams(), pk, creator, newAccount, address, owner, active, buyRam,
				stakeNetQuantity, stakeCpuQuantity, transfer));
	}

	public GetAccountResults getAccount(String accountName) throws IOException {
		GetAccountRequest req = new GetAccountRequest();
		req.setAccountName(accountName);
		try {
			return Generator.executeSync(rpcService.getAccount(req));
		} catch (ApiException e) {
			return null;
		}
	}

	public List<String> getAccounts(String publicKey) throws ApiException, IOException {
		GetAccountsRequest request = new GetAccountsRequest();
		request.setPublicKey(publicKey);
		return Generator.executeSync(rpcService.getAccounts(request)).getAccountNames();
	}

	public JSONArray getTableRows(String contractAccount, String scope, String tableName) throws ApiException, IOException {
		GetTableRowsRequest request = new GetTableRowsRequest();
		request.setCode(contractAccount);
		request.setScope(scope);
		request.setTable(tableName);
		return Generator.executeSync(rpcService.getTableRows(request)).getRows();
	}

	public GetBlockResult getBlock(String blockNumOrId) throws IOException {
		GetBlockRequest req = new GetBlockRequest();
		req.setBlockNumOrId(blockNumOrId);
		try {
			return Generator.executeSync(rpcService.getBlock(req));
		} catch (ApiException e) {
			return null;
		}
	}

	public GetInfoResults getChainInfo() throws ApiException, IOException {
		return Generator.executeSync(rpcService.getChainInfo());
	}

	public Map<String, BigDecimal> getCurrencyBalance(String account, String code) throws ApiException, IOException {
		if (account == null || code == null) {
			throw new InvalidParameterException("account or code cannot be null");
		}
		GetCurrencyBalanceRequest req = new GetCurrencyBalanceRequest();
		req.setAccount(account);
		req.setCode(code);
		List<String> list = Generator.executeSync(rpcService.getCurrencyBalance(req));
		Map<String, BigDecimal> ret = new HashMap<String, BigDecimal>();
		if (list != null) {
			list.forEach(it -> {
				String[] s = it.split(" ");
				String coinTypeCode = s[1];
				BigDecimal value = new BigDecimal(s[0]);
				ret.put(coinTypeCode, value);
			});
		}
		return ret;
	}

	public BigDecimal getCurrencyBalance(String account, String code, String symbol) throws ApiException, IOException {
		if (account == null || code == null) {
			throw new InvalidParameterException("account or code cannot be null");
		}
		if (symbol == null) {
			throw new InvalidParameterException("symbol cannot be null");
		}
		GetCurrencyBalanceRequest req = new GetCurrencyBalanceRequest();
		req.setAccount(account);
		req.setCode(code);
		req.setSymbol(symbol);
		List<String> list = Generator.executeSync(rpcService.getCurrencyBalance(req));
		if (list == null || list.isEmpty()) {
			return null;
		}
		return new BigDecimal(list.get(0).split(" ")[0]);
	}

	public CurrencyStatsResult getCurrencyStats(String code, String symbol) throws ApiException, IOException {
		if (symbol == null || code == null) {
			throw new InvalidParameterException("symbol or code cannot be null");
		}
		GetCurrencyStatsRequest req = new GetCurrencyStatsRequest();
		req.setCode(code);
		req.setSymbol(symbol);
		Map<String, CurrencyStatsResult> ret = Generator.executeSync(rpcService.getCurrencyStats(req));
		if (ret != null) {
			return ret.get(symbol);
		}
		return null;
	}
/*
	public GetTransactionResult getTransaction(String transactionId) throws IOException {
		if (transactionId == null) {
			throw new InvalidParameterException("transactionId cannot be null");
		}
		GetTransactionRequest req = new GetTransactionRequest();
		req.setId(transactionId);
		try {
			GetTransactionResult t = Generator.executeSync(rpcService.getTransaction(req));
			if (t == null || t.getTrx() == null || !transactionId.equals(t.getId())) {
				return null;
			}
			return t;
		} catch (ApiException e) {
			return null;
		}
	}
*/
	public PushTransactionResults pushTransaction(SignedTransactionToPush pushTransaction)
			throws ApiException, IOException {
		return pushTransaction(pushTransaction.getCompression(), pushTransaction.getTransaction(),
				pushTransaction.getSignatures());
	}

	public PushTransactionResults pushTransaction(String compression, Transaction pushTransaction, String[] signatures)
			throws ApiException, IOException {
		return Generator.executeSync(
				rpcService.pushTransaction(new PushTransactionRequest(compression, pushTransaction, signatures)));
	}

	public PushTransactionResults transfer(String pk, String contractAccount, String from, String to, String quantity,
										   String memo) throws ApiException, IOException {
		return pushTransaction(txBuilder.buildTransferRawTx(txBuilder.getSignParams(), pk, contractAccount, from, to, quantity, memo));
	}

	public PushTransactionResults transferExt(String pk, String contractAccount, String from, String fromAddress, String toAddress, String quantity,
										   String memo) throws ApiException, IOException {
		return pushTransaction(txBuilder.buildTransferExtRawTx(txBuilder.getSignParams(), pk, contractAccount, from, fromAddress, toAddress, quantity, memo));
	}

    public PushTransactionResults transferExt(String pk, String contractAccount, String fromAddress, String toAddress, String quantity,
                                              String memo) throws ApiException, IOException {
        return pushTransaction(txBuilder.buildTransferExtRawTx(txBuilder.getSignParams(), pk, contractAccount, BusUtil.getAccountNameByMainOrSubAddress(fromAddress), fromAddress, toAddress, quantity, memo));
    }

	public PushTransactionResults transferExtWithMark(String pk, String contractAccount, String fromAddress, String toAddress, String quantity,
									  String memo, String mark) throws ApiException, IOException {
		return pushTransaction(txBuilder.buildTransferExtWithMarkRawTx(txBuilder.getSignParams(), pk, contractAccount, BusUtil.getAccountNameByMainOrSubAddress(fromAddress), fromAddress, toAddress, quantity, memo, mark));
	}

	public PushTransactionResults addHdAddress(String pk, String contractAccount, String account, String address) throws ApiException, IOException {
		return pushTransaction(txBuilder.buildAddHdAddressRawTx(txBuilder.getSignParams(), pk, contractAccount, account, address));
	}
	
	public PushTransactionResults addHdAddressList(String pk, String contractAccount, String account, List<String> addressList) throws ApiException, IOException {
		return pushTransaction(txBuilder.buildAddHdAddressRawTxList(txBuilder.getSignParams(), pk, contractAccount, account, addressList));
	}

	public PushTransactionResults addAttachPermission(String pk, String account, String permission, String parent, String publicKey, String codeAccount,  String codePermission) throws ApiException, IOException {
		return pushTransaction(txBuilder.buildAddAttachPermissionRawTx(txBuilder.getSignParams(), pk, account, permission, parent, publicKey, codeAccount, codePermission));
	}

	public PushTransactionResults removeAttachPermission(String pk, String account, String permission, String parent, String publicKey) throws ApiException, IOException {
		return pushTransaction(txBuilder.buildRemoveAttachPermissionRawTx(txBuilder.getSignParams(), pk, account, permission, parent, publicKey));
	}

	public PushTransactionResults addNewPermission(String pk, String account, String permission, String parent, String publicKey) throws ApiException, IOException {
		return pushTransaction(txBuilder.buildAddNewPermissionRawTx(txBuilder.getSignParams(), pk, account, permission, parent, publicKey));
	}

	public PushTransactionResults deletePermission(String pk, String account, String permission) throws ApiException, IOException {
		return pushTransaction(txBuilder.buildDeletePermissionRawTx(txBuilder.getSignParams(), pk, account, permission));
	}

	public PushTransactionResults linkAuth(String pk, String account, String code, String type, String requirement) throws ApiException, IOException {
		return pushTransaction(txBuilder.buildLinkAuthRawTx(txBuilder.getSignParams(), pk, account, code, type, requirement));
	}

	public PushTransactionResults unLinkAuth(String pk, String account, String code, String type) throws ApiException, IOException {
		return pushTransaction(txBuilder.buildUnLinkAuthRawTx(txBuilder.getSignParams(), pk, account, code, type));
	}

	public PushTransactionResults applyIssue(String pk, String account) throws ApiException, IOException {
		return pushTransaction(txBuilder.buildApplyIssueRawTx(txBuilder.getSignParams(), pk, account));
	}

	public PushTransactionResults unApplyIssue(String pk, String account) throws ApiException, IOException {
		return pushTransaction(txBuilder.buildUnApplyIssueRawTx(txBuilder.getSignParams(), pk, account));
	}

	public PushTransactionResults voteProducer(String pk, String voter, String proxy, List<String> producers)
			throws ApiException, IOException {
		return pushTransaction(txBuilder.buildVoteProducerRawTx(txBuilder.getSignParams(), pk, voter, proxy, producers));
	}
	
	public PushTransactionResults buyram(String pk, String creator, String receiver, String quant)
			throws ApiException, IOException {
		return pushTransaction(txBuilder.buildBuyramRawTx(txBuilder.getSignParams(), pk, creator, receiver, quant));
	}

	public PushTransactionResults sellram(String pk, String account, Long sellRam)
			throws ApiException, IOException {
		return pushTransaction(txBuilder.buildSellramRawTx(txBuilder.getSignParams(), pk, account, sellRam));
	}

	public PushTransactionResults delegatebw(String pk, String from, String receiver, String stakeNetQuantity, String stakeCpuQuantity, Long transfer)
			throws ApiException, IOException {
		return pushTransaction(txBuilder.buildDelegatebwRawTx(txBuilder.getSignParams(), pk, from, receiver, stakeNetQuantity,stakeCpuQuantity,transfer));
	}
	
	public PushTransactionResults unDelegatebw(String pk, String from, String receiver, String stakeNetQuantity, String stakeCpuQuantity)
			throws ApiException, IOException {
		return pushTransaction(txBuilder.buildUnDelegatebwRawTx(txBuilder.getSignParams(), pk, from, receiver, stakeNetQuantity,stakeCpuQuantity));
	}

	public PushTransactionResults updateUserAuthKey(String pk, String actor, String kind, String newPublicKey)
			throws ApiException, IOException {
		return pushTransaction(txBuilder.buildUpdateUserAuthKeyRawTx(txBuilder.getSignParams(), pk, actor, kind, newPublicKey));
	}
	
	public PushTransactionResults addNeedMoreSign(String accountPrivateKey, String address)
			throws ApiException, IOException {
		return pushTransaction(txBuilder.buildNeedMoreSign(txBuilder.getSignParams(), accountPrivateKey, BusUtil.getAccountNameByMainOrSubAddress(address), "addneedmsign"));
	}
	
	public PushTransactionResults remNeedMoreSign(String accountPrivateKey, String address)
			throws ApiException, IOException {
		return pushTransaction(txBuilder.buildNeedMoreSign(txBuilder.getSignParams(), accountPrivateKey, BusUtil.getAccountNameByMainOrSubAddress(address), "remneedmsign"));
	}
	
	public List<NeedMoreSign> getNeedMoreSignAll() throws ApiException, IOException {
		List<NeedMoreSign> listNeedMoreSignAll = new ArrayList<NeedMoreSign>();
		String str = "";
		GetTableRowsResults tableRows = new GetTableRowsResults();
		do {
			List<NeedMoreSign> needMoreSign = new ArrayList<NeedMoreSign>();
			tableRows = getTableRows("sys.token", "sys.token", "needmoresign", str, null, 1000);
			if (tableRows.getRows().size() != 0) {
				needMoreSign = JSONObject.parseArray(JSONObject.toJSONString(tableRows.getRows()), NeedMoreSign.class);
			}
			if(tableRows.getMore()) {
				str = needMoreSign.get(needMoreSign.size()-1).toString();
				needMoreSign = needMoreSign.subList(0, needMoreSign.size()-1);
			}
			listNeedMoreSignAll.addAll(needMoreSign);
		} while (tableRows.getMore());
		return listNeedMoreSignAll;
	}
	
	public NeedMoreSign getNeedMoreSignOne(String address) throws ApiException, IOException {
		GetTableRowsResults tableRows = getTableRows("sys.token", "sys.token", "needmoresign", BusUtil.getAccountNameByMainOrSubAddress(address),
				BusUtil.getAccountNameByMainOrSubAddress(address),1);
		NeedMoreSign needMoreSign = null;
		if (tableRows.getRows().size() != 0) {
			JSONObject jsonObject = tableRows.getRows().getJSONObject(0);
			if (jsonObject.getString("owner") != null) {
				if (jsonObject.getString("owner").equals(BusUtil.getAccountNameByMainOrSubAddress(address))) {
					needMoreSign = JSONObject.toJavaObject(tableRows.getRows().getJSONObject(0), NeedMoreSign.class);
				}
			}
		}
		return needMoreSign;
	}
	
	public GetTableRowsResults getTableRows(String contractAccount, String scope, String tableName, String lower,String upper,
			Integer limit) throws ApiException, IOException {
		GetTableRowsRequest request = new GetTableRowsRequest();
		request.setLimit(limit);
		request.setLowerBound(lower);
		if(upper!=null) {
			request.setUpperBound(upper);
		}
		request.setCode(contractAccount);
		request.setScope(scope);
		request.setTable(tableName);
		return Generator.executeSync(rpcService.getTableRows(request));
	}
	
	public PushTransactionResults collect(String sysauthPrivateKey, String bpName)
			throws ApiException, IOException {
		return pushTransaction(txBuilder.buildCollect(txBuilder.getSignParams(), sysauthPrivateKey, bpName, "collect"));
	}
	
	public List<String> getAllBp() throws ApiException, IOException {
		List<String> allBpNameList =new ArrayList<>();
		List<GetBpName> listAllBp = new ArrayList<GetBpName>();
		String str = "";
		GetTableRowsResults tableRows = new GetTableRowsResults();
		do {
			List<GetBpName> listBpName = new ArrayList<GetBpName>();
			tableRows = getTableRows("eos", "eos", "producers", str, null, 33);
			if (tableRows.getRows().size() != 0) {
				listBpName = JSONObject.parseArray(JSONObject.toJSONString(tableRows.getRows()), GetBpName.class);
			}
			if (tableRows.getMore()) {
				str = listBpName.get(listBpName.size() - 1).getOwner().toString();
				listBpName = listBpName.subList(0, listBpName.size() - 1);
			}
			listAllBp.addAll(listBpName);
		} while (tableRows.getMore());
		for (int i = 0; i < listAllBp.size(); i++) {
			allBpNameList.add(listAllBp.get(i).getOwner());
		}
		return allBpNameList;
	}
	
}
