import com.alibaba.fastjson.JSON;
import eos.sdk.SdkClient;
import eos.sdk.SdkOfflineSignClient;
import eos.sdk.api.result.GetInfoResults;
import eos.sdk.api.result.PushTransactionResults;
import eos.sdk.client.exception.ApiException;
import eos.sdk.dto.ErrorInfoDTO;
import eos.sdk.utils.BusUtil;

public class TestFirst {
    static final String sysAuthPrivate = "5K4bNKYKSYE13oS84BJAYuGfiq4G1icGEwNsnaLmtXY9emy8Fbv";
    static final String testAccount1 = "helloworld11";
    static final String testAccount1Private = "5KPaMgPMLTTxkvYSe8SE6rjLXMCVaC9DmacyvTXBRsV25mJt6nh";
    static final String testAccount1Address = "B7rxvPooPAG3nptzN2o5roFpHVX2bTMjAmEDkbkV1ZisrADfCV";

    static final String testAccount2 = "helloworld12";
    static final String testAccount2Private = "5K5K5EtoFz2HKgdhg88sPj5FBf6zVwmfSvYmjKtARp2yyCV95hE";
    static final String testAccount2Address = "B7YmcWFgwfnXP7kbMxoKZ6vF5Dp64TCFRMvpZNSd7adXo8jNnp4";

    static final String testAccount3 = "helloworld1a";
    static final String testAccount3Private = "5KFgpXJmRJ88WmKVgy5fxffDJTty8gAfyHuduJKEa5xFxmTsdWq";
    static final String testAccount3Address = "B5AxZ1vdK9r6JeLXUjShRXcd4Wzf874VTathjr8ibnQE72npue6";

    static final String testAccount4 = "helloworld2a";
    static final String testAccount4Private = "5KRyvqPZK4NtHerbyxfQtQtpbMLMDZg8DJ14G93HzVaZjwFYhfj";
    static final String testAccount4Address = "B8mCATiKpNQvCUJjD2r6p8qv1rD9LyWRCnsuEpGcbAfMwxqC4Zd";

    static final String testAccount5 = "helloworld1d";
    static final String testAccount5Private = "5Kcn7ZhQMs42Gco48c7Lig8JcAftnVq8D3zmPhiGTKpRDCECDmo";
    static final String testAccount5Address = "B5Nooe4rZM4F2RN5nADsqGYBN8Rs7nrosYdVJha8nKVUVQBcjc7";

    static final String testAccount6 = "needmoresign";
    static final String testAccount6Private = "5KL9tK5crjsJhqCVJyWE9MaZRexyd7P4rmp6VBPGXms6H1xF2wb";

    static final String testCreatorAccount = "sys.resad";
    static final String testCreatorAccountPrivateKey = "5Hv2wunXqJL71n3Wx7rSYzKyBgA7DYu66z4xpL9WScGzarnWjkL";
    static final Long buyRam = 8000l;
    static final String stakeNetQuantity = "10.0000 BUS";
    static final String stakeCpuQuantity = "10.0000 BUS";
    static final Long transfer = 0l;

    public static void main(String[] args){
        String url = "https://eospush.tokenpocket.pro";
        SdkClient sdkClient = new SdkClient(url);
        SdkOfflineSignClient sdkOfflineSignClient = new SdkOfflineSignClient(url);
        PushTransactionResults pushTransactionResults = null;
        try {
            GetInfoResults infoResults = sdkClient.getChainInfo();
            System.out.println("getinfo = " + JSON.toJSONString(infoResults));
            System.out.println("当前出块节点 = " + infoResults.getHeadBlockProducer());
//            System.out.println("随机创建私钥 = " + BusKeyUtils.randomKey());
//            System.out.println("通过私钥获取公钥 = " + BusKeyUtils.getPublicKey(testAccount1Private));
//            String randomName = BusUtil.randomName();
//            System.out.println("随机创建账户名 = " + randomName);
//            String randomAddress = BusUtil.randomAddress();
//            System.out.println("随机创建地址 = " + randomAddress);
//            String randomMainAddress = BusUtil.randomMainAddress(randomName);
//            System.out.println("随机创建该账户主地址地址 = " + randomMainAddress);
//            String randomSubAddress = BusUtil.randomSubAddress(randomName);
//            System.out.println("随机创建该账户子地址地址 = " + randomSubAddress);
//            System.out.println("根据主地址或子地址提取账户名 = " + BusUtil.getAccountNameByMainOrSubAddress(randomMainAddress));
//            String randomPublicKey = BusKeyUtils.randomPubKey();
//            System.out.println("随机创建公钥 = " + randomPublicKey);
//            System.out.println("公钥验证 = " + BusUtil.checkPublicKey("BUS7116Z5JatthYFQWq7S5fhNRjKwfGizYScuwBuiVNSFYCnUN8wP"));
//            System.out.println("地址验证 = " + BusUtil.checkAddress("B7116Z5JatthYFQWq7S5fhNRjKwfGizYScuwBuiVNSFYCnUN8wP"));
//            System.out.println("TransferExt json to bin 临时方案 = " + sdkOfflineSignClient.buildTransferExtBin("sys.token", testAccount1,testAccount1Address, testAccount2Address,"2.0000 BUS", ""));
//            // 数据获取
//            GetAccountResults r = sdkClient.getAccount(testAccount1);
//            System.out.println(JSON.toJSONString(r));
//            CurrencyStatsResult cr = sdkClient.getCurrencyStats("sys.token","BUS");
//            System.out.println(JSON.toJSONString(cr));
//            System.out.println(sdkClient.getCurrencyBalance(testAccount1,"sys.token","BUS"));
//            // 实时推送
//            pushTransactionResults = sdkClient.createAccount(testCreatorAccountPrivateKey, testCreatorAccount, randomName, randomMainAddress,
//                    randomPublicKey, randomPublicKey, buyRam, stakeNetQuantity, stakeCpuQuantity, transfer);
//            System.out.println("创建新账户 = " + pushTransactionResults.getTransactionId()+" \n ");
//
//            pushTransactionResults = sdkClient.transfer(testAccount2Private,"sys.token", testAccount2,testAccount1, "12.0000 BUS", "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
//            System.out.println("转账成功 交易ID:= " + pushTransactionResults.getTransactionId()+" \n ");
//            System.out.println("转账成功 交易块号：= " + pushTransactionResults.getProcessed().getBlockNum()+" \n ");
//
//            pushTransactionResults = sdkClient.transferExt(testAccount1Private,"sys.token", testAccount1,testAccount1Address, testAccount2Address,"2.0000 BUS", "");
//            System.out.println("转账成功 = " + pushTransactionResults.getTransactionId()+" \n ");
//
//            pushTransactionResults = sdkClient.transferExt(testAccount1Private,"sys.token", testAccount1Address, testAccount2Address,"2.0000 BUS", "");
//            System.out.println("新地址规则转账成功 = " + pushTransactionResults.getTransactionId()+" \n ");
//
//            pushTransactionResults = sdkClient.transferExtWithMark(testAccount1Private,"sys.token", testAccount1Address, testAccount2Address,"2.0000 BUS", "memo","944c1698dc62c1817cc02c68207c47bf85dfc7e830839d2ab7267899bb04ada9");
//            System.out.println("带有标记性得转账成功 = " + pushTransactionResults.getTransactionId()+" \n ");
//
//            pushTransactionResults = sdkClient.addHdAddress(sysAuthPrivate,"eos", randomName,randomSubAddress);
//            System.out.println("添加子地址成功 = " + pushTransactionResults.getTransactionId()+" \n ");
//
//            //批量添加子地址
//            List<String> randomSubAddressList = new ArrayList<String>();
//    		String accountNameTest = "portestusera";
//    		for (int i = 0; i < 5; i++) {
//    			randomSubAddressList.add(BusUtil.randomSubAddress(accountNameTest));
//    		}
//    		PushTransactionResults addHdAddressList = sdkClient.addHdAddressList(sysAuthPrivate,"eos", accountNameTest,randomSubAddressList);
//    		System.out.println(addHdAddressList.getTransactionId());
//
//            // 离线推送
//            SimpleDateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
//            dateFormatter.setTimeZone(TimeZone.getTimeZone("UTC"));
//
//            SignParam param = sdkOfflineSignClient.getSignParams();
//            String paramStr = sdkOfflineSignClient.SignParamToString(param);
//            param = sdkOfflineSignClient.StringToSignParam(paramStr);
//            System.out.println("paramStr = " + paramStr+" \n ");
//            System.out.println("chainId = " + param.getChainId()+" \n ");
//            System.out.println("expiration = " + dateFormatter.format(param.getExpiration())+" \n ");
//            System.out.println("refBlockNum = " + param.getRefBlockNum()+" \n ");
//            System.out.println("refBlockPrefix = " + param.getRefBlockPrefix()+" \n ");
//
//            String offTrx = sdkOfflineSignClient.transferExt(param, testAccount1Private,"sys.token", testAccount1,testAccount1Address, testAccount2Address,"2.0000 BUS", "");
//            System.out.println("offTrx = " + offTrx+" \n ");
//            pushTransactionResults = sdkOfflineSignClient.pushTransaction(offTrx);
//            System.out.println("离线转账成功 = " + pushTransactionResults.getTransactionId()+" \n ");
//
//            offTrx = sdkOfflineSignClient.transferExt(param, testAccount1Private,"sys.token", testAccount1Address, testAccount2Address,"2.0000 BUS", "");
//            pushTransactionResults = sdkOfflineSignClient.pushTransaction(offTrx);
//            System.out.println("新地址规则离线转账成功 = " + pushTransactionResults.getTransactionId()+" \n ");
//
//            offTrx = sdkOfflineSignClient.transferExt(param, testAccount1Private,"sys.token", testAccount1Address, testAccount2Address,"2.0000 BR", "");
//            SignedTransactionToPush signedTransaction = sdkOfflineSignClient.StringToSignedTransaction(offTrx);
//            Transaction tx = signedTransaction.getTransaction();
//            String sign = EccTool.signTransaction(testAccount6Private, new TransactionToSign(signedTransaction.getTxId(), tx));
//            String[] signatures = signedTransaction.getSignatures();
//            signatures[signatures.length] = sign;
//            signedTransaction.setSignatures(signatures);
//            pushTransactionResults = sdkClient.pushTransaction(signedTransaction);
//            System.out.println("新地址规则附加签名离线转账成功 = " + pushTransactionResults.getTransactionId()+" \n ");
//
//            offTrx = sdkOfflineSignClient.transferExtWithMark(param, testAccount1Private,"sys.token", testAccount1Address, testAccount2Address,"2.0000 BUS", "memo","944c1698dc62c1817cc02c68207c47bf85dfc7e830839d2ab7267899bb04ada9");
//            pushTransactionResults = sdkOfflineSignClient.pushTransaction(offTrx);
//            System.out.println("带有标记性得离线转账成功 = " + pushTransactionResults.getTransactionId()+" \n ");
//
//            JSONArray rows = sdkClient.getTableRows("sys.oracle","sys.oracle", "feeratetb");
//            offTrx = sdkOfflineSignClient.transferExtWithFee(param, testAccount1Private,"sys.token", testAccount1Address, testAccount2Address,"2.0000 BUS", "", "");
//            pushTransactionResults = sdkOfflineSignClient.pushTransaction(offTrx);
//            System.out.println("新地址规则加手续费离线转账成功 = " + pushTransactionResults.getTransactionId()+" \n ");
//
//            offTrx = sdkOfflineSignClient.applyIssue(param, testAccount5Private, testAccount5);
//            pushTransactionResults = sdkOfflineSignClient.pushTransaction(offTrx);
//            System.out.println("离线申请发币权限 = " + pushTransactionResults.getTransactionId()+" \n ");
//
//            offTrx = sdkOfflineSignClient.unApplyIssue(param, testAccount5Private, testAccount5);
//            pushTransactionResults = sdkOfflineSignClient.pushTransaction(offTrx);
//            System.out.println("离线取消发币权限 = " + pushTransactionResults.getTransactionId()+" \n ");
//
//            // 特殊方案：后端创建交易体，前端补全签名
//            SignedTransactionToPush signTrx = new SignedTransactionToPush();
//            String needSignOffTrx = sdkOfflineSignClient.needSignApplyIssue(param, testAccount5);
//            NeedSignedTransactionToPush needSignTrx= sdkOfflineSignClient.StringToNeedSignedTransaction(needSignOffTrx);
//            signTrx.setCompression(needSignTrx.getCompression());
//            signTrx.setTransaction(needSignTrx.getTransaction());
//            signTrx.setTxId(needSignTrx.getTxId());
//            signTrx.setSignatures(new String[] {EccTool.signHash(testAccount5Private, needSignTrx.getByteToSignHash()) });
//            offTrx = sdkOfflineSignClient.SignedTransactionToString(signTrx);
//            pushTransactionResults = sdkOfflineSignClient.pushTransaction(offTrx);
//            System.out.println("特殊离线申请发币权限 = " + pushTransactionResults.getTransactionId()+" \n ");
//
//            String needUnSignOffTrx = sdkOfflineSignClient.needSignUnApplyIssue(param, testAccount5);
//            NeedSignedTransactionToPush needUnSignTrx= sdkOfflineSignClient.StringToNeedSignedTransaction(needUnSignOffTrx);
//            signTrx.setCompression(needUnSignTrx.getCompression());
//            signTrx.setTransaction(needUnSignTrx.getTransaction());
//            signTrx.setTxId(needUnSignTrx.getTxId());
//            signTrx.setSignatures(new String[] {EccTool.signHash(testAccount5Private, needUnSignTrx.getByteToSignHash()) });
//            offTrx = sdkOfflineSignClient.SignedTransactionToString(signTrx);
//            pushTransactionResults = sdkOfflineSignClient.pushTransaction(offTrx);
//            System.out.println("特殊离线取消申请发币权限 = " + pushTransactionResults.getTransactionId()+" \n ");
//
//            // 非常用方法
//            pushTransactionResults = sdkClient.unLinkAuth(testAccount1Private, testAccount1, "eos", "setcode");
//            System.out.println("删除setcode权限 = " + pushTransactionResults.getTransactionId()+" \n ");
//
//            pushTransactionResults = sdkClient.unLinkAuth(testAccount1Private, testAccount1, "eos", "setabi");
//            System.out.println("删除setabi权限 = " + pushTransactionResults.getTransactionId()+" \n ");
//
//            pushTransactionResults = sdkClient.deletePermission(testAccount1Private, testAccount1, "share");
//            System.out.println("删除权限 = " + pushTransactionResults.getTransactionId()+" \n ");
//
//            pushTransactionResults = sdkClient.addNewPermission(testAccount1Private, testAccount1, "share", "active", BusKeyUtils.getPublicKey(testAccount1Private));
//            System.out.println("添加新权限 = " + pushTransactionResults.getTransactionId()+" \n ");
//
//            pushTransactionResults = sdkClient.addAttachPermission(testAccount1Private, testAccount1, "share", "active", BusKeyUtils.getPublicKey(testAccount1Private), testCreatorAccount, "active");
//            System.out.println("附加权限 = " + pushTransactionResults.getTransactionId()+" \n ");
//
//            pushTransactionResults = sdkClient.linkAuth(testAccount1Private, testAccount1, "eos", "setcode", "share");
//            System.out.println("附加setcode权限 = " + pushTransactionResults.getTransactionId()+" \n ");
//
//            pushTransactionResults = sdkClient.linkAuth(testAccount1Private, testAccount1, "eos", "setabi", "share");
//            System.out.println("附加setabi权限 = " + pushTransactionResults.getTransactionId()+" \n ");
//
//            pushTransactionResults = sdkClient.removeAttachPermission(testAccount1Private, testAccount1, "share", "active", BusKeyUtils.getPublicKey(testAccount1Private));
//            System.out.println("删除附加权限 = " + pushTransactionResults.getTransactionId()+" \n ");
//
//            pushTransactionResults = sdkClient.deletePermission(testAccount1Private, testAccount1, "share");
//            System.out.println("删除权限 = " + pushTransactionResults.getTransactionId()+" \n ");
//
        } catch (ApiException e) {
            ErrorInfoDTO errInfo = BusUtil.getErrorInfo(e);
            System.out.println("ApiException = code: " + errInfo.getCode() + " message: " + errInfo.getMessage() + " \n ");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
