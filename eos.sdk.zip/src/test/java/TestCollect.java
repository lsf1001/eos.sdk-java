import java.io.IOException;
import java.math.BigDecimal;
import java.util.List;

import org.junit.Test;

import eos.sdk.SdkClient;
import eos.sdk.api.result.PushTransactionResults;
import eos.sdk.client.exception.ApiException;

public class TestCollect {
	String url = "http://192.168.7.57:8888";
	SdkClient sdkClient = new SdkClient(url);

	@Test
	// 查询所有BP账户名
	public void getAllBp() throws ApiException, IOException {
		List<String> allBp = sdkClient.getAllBp();
		for (int i = 0; i < allBp.size(); i++) {
			System.out.println(allBp.get(i));
		}
	}
	
	@Test
	// BP资金归集到归集账户
	public void collect() throws ApiException, IOException {
		String bpAccount = "v3ldhmdsn5ig";
		BigDecimal bpBalance = sdkClient.getCurrencyBalance(bpAccount, "sys.token", "BR");
		System.out.println("bp账户余额："+bpBalance);
		BigDecimal colletBalance = sdkClient.getCurrencyBalance("sys.resad", "sys.token", "BR");
		System.out.println("资金归集账户余额："+colletBalance);
		
		//参数1是sys.auth的私钥，此账户为后台操作账户，参数2为BP名，上一个方法查询的结果
		PushTransactionResults collect = sdkClient.collect("5K4bNKYKSYE13oS84BJAYuGfiq4G1icGEwNsnaLmtXY9emy8Fbv",bpAccount);
		System.out.println("归集的交易id:"+collect.getTransactionId());
		
		BigDecimal bpBalance1 = sdkClient.getCurrencyBalance(bpAccount, "sys.token", "BR");
		System.out.println("bp账户余额："+bpBalance1);
		BigDecimal colletBalance1 = sdkClient.getCurrencyBalance("sys.resad", "sys.token", "BR");
		System.out.println("资金归集账户余额："+colletBalance1);
	}

}
