import eos.sdk.SdkClient;
import eos.sdk.SdkOfflineSignClient;
import eos.sdk.api.result.NeedMoreSign;
import eos.sdk.api.result.PushTransactionResults;
import eos.sdk.client.exception.ApiException;
import eos.sdk.client.transaction.SignParam;
import eos.sdk.client.transaction.SignedTransactionToPush;
import eos.sdk.utils.BusUtil;
import eos.sdk.utils.SetMoreSignUtil;

import org.junit.Test;

import java.io.IOException;
import java.util.List;

public class MoreSign {
    static String url = "http://47.56.87.250:8888";
    static SdkClient sdkClient = new SdkClient(url);
    static SdkOfflineSignClient sdkOfflineSignClient = new SdkOfflineSignClient(url);

	@Test
	public void addNeedMoreSign() throws ApiException, IOException {
		PushTransactionResults pushTransactionResults = sdkClient
				.addNeedMoreSign("5K4bNKYKSYE13oS84BJAYuGfiq4G1icGEwNsnaLmtXY9emy8Fbv", "BMRB33VW4WWWEODfGvCQDW81rkG4nsSgVdm8pzeQz44efPcfWAW");
		System.out.println("交易id=" + pushTransactionResults.getTransactionId());
	}

	@Test
	public void remNeedMoreSign() throws ApiException, IOException {
		PushTransactionResults pushTransactionResults = sdkClient
				.remNeedMoreSign("5K4bNKYKSYE13oS84BJAYuGfiq4G1icGEwNsnaLmtXY9emy8Fbv", "BMRB33VW4WWWEODfGvCQDW81rkG4nsSgVdm8pzeQz44efPcfWAW");
		System.out.println("交易id=" + pushTransactionResults.getTransactionId());
	}

    @Test
    public void transfer() throws Exception {
//        System.setProperty("http.proxyHost", "127.0.0.1");
//        System.setProperty("https.proxyHost", "127.0.0.1");
//        System.setProperty("http.proxyPort", "8888");
//        System.setProperty("https.proxyPort", "8888");

        SignParam param = sdkOfflineSignClient.getSignParams();
        String paramStr = sdkOfflineSignClient.SignParamToString(param);
        param = sdkOfflineSignClient.StringToSignParam(paramStr);
        String offTrx = sdkOfflineSignClient.transferExtWithMoreSign(param, "5JP5DnUx8b1sq5ECLpkvxCRKADhKjVgiVr34EVbMsPBKuxiLo7o",
                "sys.token", "BMRB33VW4WWWEODfGvCQDW81rkG4nsSgVdm8pzeQz44efPcfWAW",
                "BMDLWPSSQV1UGYBUZnYTyTADKxkvjnwF42RUbWnLwaN7pHB54KQ", "0.00000001 BR", "");
        SignedTransactionToPush signedTransaction = sdkOfflineSignClient.StringToSignedTransaction(offTrx);
        SetMoreSignUtil.setMoreSign("5KL9tK5crjsJhqCVJyWE9MaZRexyd7P4rmp6VBPGXms6H1xF2wb", param.getChainId(), signedTransaction);
        PushTransactionResults pushTransactionResults = sdkClient.pushTransaction(signedTransaction);
        System.out.println("新地址规则附加签名离线转账成功 = " + pushTransactionResults.getTransactionId() + " \n ");
    }

	@Test
	//精确查询链上限制列表是否有次账户
	public void getNeedMoreSignOne() throws ApiException, IOException {
		NeedMoreSign needMoreSignOne = sdkClient.getNeedMoreSignOne("BMRB33VW4WWWEODfGvCQDW81rkG4nsSgVdm8pzeQz44efPcfWAW");
		if(needMoreSignOne.getOwner().equals(BusUtil.getAccountNameByMainOrSubAddress("BMRB33VW4WWWEODfGvCQDW81rkG4nsSgVdm8pzeQz44efPcfWAW"))) {
			System.out.println("列表已有此账户");
		}
	}
	
	@Test
	//查询链上限制列表全部账户
	public void getNeedMoreSignAll() throws ApiException, IOException {
		List<NeedMoreSign> needMoreSignAll = sdkClient.getNeedMoreSignAll();
		for (int i = 0; i < needMoreSignAll.size(); i++) {
			System.out.println("列表中账户已有："+needMoreSignAll.get(i).getOwner());
		}
	}
}
